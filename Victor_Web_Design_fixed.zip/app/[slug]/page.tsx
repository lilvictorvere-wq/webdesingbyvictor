import {notFound} from 'next/navigation';
import Link from '@/components/site-link';
import PageIntro from '@/components/page-intro';
import {services} from '@/lib/content';
import {base,JsonLd,meta} from '@/lib/seo';
import {CTA,FAQ} from '@/components/sections';
import {Check,ArrowUpRight} from 'lucide-react';
export function generateStaticParams(){return services.map(s=>({slug:s.slug}))}
export async function generateMetadata({params}:{params:Promise<{slug:string}>}){const {slug}=await params;const s=services.find(s=>s.slug===slug);return s?meta(s.name,s.description,'/'+slug):{title:'Pagină inexistentă'}}
export default async function Page({params}:{params:Promise<{slug:string}>}){const {slug}=await params;const s=services.find(s=>s.slug===slug);if(!s)notFound();return <><PageIntro title={s.name} description={s.description} path={'/'+slug}/><section className="section service-detail"><div><span className="eyebrow">CONSTRUIT PENTRU AFACEREA TA</span><h2>De la obiectiv<br/>la experiență.</h2><p>{s.detail}</p><Link className="button primary" href="/contact">Discută proiectul <ArrowUpRight size={18}/></Link></div><div className="feature-list">{s.features.map((f,i)=><div key={f}><span>0{i+1}</span><h3>{f}</h3><Check size={20}/></div>)}</div></section><FAQ/><CTA/><JsonLd data={{'@context':'https://schema.org','@type':'Service',name:s.name,description:s.detail,url:base+'/'+slug,provider:{'@id':base+'/#organization'},areaServed:'România'}}/></>}
