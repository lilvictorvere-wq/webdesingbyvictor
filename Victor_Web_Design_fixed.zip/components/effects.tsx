'use client';
import { Component, useCallback, useEffect, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import Image from 'next/image';
import dynamic from 'next/dynamic';
import { cinematicState } from '@/lib/cinematic-state';
const AncientScene = dynamic(() => import('./ancient-scene'), { ssr: false });
class SceneBoundary extends Component<{children:ReactNode,onFailure:()=>void}, {failed:boolean}> {
  state = {failed:false};
  static getDerivedStateFromError(){return {failed:true};}
  componentDidCatch(){this.props.onFailure();}
  render(){return this.state.failed?null:this.props.children;}
}
export function HeroArt({ compact = false }: {compact?:boolean}) {
  const [enabled,setEnabled] = useState(false);
  const [ready,setReady] = useState(false);
  const container=useRef<HTMLDivElement>(null);
  const onReady=useCallback(()=>setReady(true),[]);
  const onFailure=useCallback(()=>{setReady(false);setEnabled(false);},[]);
  useEffect(()=>{
    const mq=matchMedia('(prefers-reduced-motion: reduce)');
    const width=matchMedia('(min-width:600px)');
    let inRange=false,supported=false,frame=0;
    try{const context=document.createElement('canvas').getContext('webgl2');supported=!!context;context?.getExtension('WEBGL_lose_context')?.loseContext();}catch{}
    const update=()=>{const next=inRange&&supported&&!mq.matches&&width.matches&&(navigator.hardwareConcurrency||4)>=4;setEnabled(next);if(!next)setReady(false);};
    const observer=new IntersectionObserver(([entry])=>{if(entry.isIntersecting){inRange=true;update();}},{rootMargin:'150px'});
    frame=requestAnimationFrame(()=>{if(container.current)observer.observe(container.current);});
    mq.addEventListener('change',update);width.addEventListener('change',update);
    return()=>{observer.disconnect();cancelAnimationFrame(frame);mq.removeEventListener('change',update);width.removeEventListener('change',update);};
  },[]);
  useEffect(()=>{const canvas=container.current?.querySelector('canvas');if(!canvas)return;const lost=(e:Event)=>{e.preventDefault();onFailure();};canvas.addEventListener('webglcontextlost',lost);return()=>canvas.removeEventListener('webglcontextlost',lost);},[ready,onFailure]);
  return <div ref={container} className={(compact?'temple-art':'hero-art')+(ready?' scene-ready':'')} aria-hidden="true">
    <div className="ancient-fallback"><Image src={compact?'/textures/temple-fallback.webp':'/textures/hero-fallback.webp'} alt="" fill sizes={compact?'50vw':'(max-width: 700px) 100vw, 75vw'} priority={!compact}/></div>
    {enabled&&<SceneBoundary onFailure={onFailure}><div className="canvas-layer"><AncientScene onReady={onReady} compact={compact}/></div></SceneBoundary>}
    {!compact&&<><span className="art-label">L’ART DU DIGITAL / MMXXVI</span><span className="art-coordinate">FORMĂ · LUMINĂ · EXPERIENȚĂ</span></>}
  </div>;
}
export function Reveal({children,className='',delay=0}:{children:ReactNode,className?:string,delay?:number}) {
  return <div className={className} data-reveal-card data-reveal-delay={delay}>{children}</div>;
}
export function Tilt({children,className=''}:{children:ReactNode,className?:string}) {
  return <div className={'tilt '+className} onPointerMove={e=>{if(e.pointerType!=='mouse'||matchMedia('(prefers-reduced-motion: reduce)').matches)return;const r=e.currentTarget.getBoundingClientRect();e.currentTarget.style.transform=`perspective(1200px) rotateX(${-(e.clientY-r.top-r.height/2)/80}deg) rotateY(${(e.clientX-r.left-r.width/2)/80}deg)`;}} onPointerLeave={e=>{e.currentTarget.style.transform='';}}>{children}</div>;
}
export function ScrollEffects() {
  useEffect(()=>{
    let active=true; let cleanup=()=>{};
    Promise.all([import('gsap'),import('gsap/ScrollTrigger')]).then(([{gsap},{ScrollTrigger}])=>{
      if(!active)return;
      gsap.registerPlugin(ScrollTrigger);
      const media=gsap.matchMedia();
      cleanup=()=>media.revert();
      media.add('(prefers-reduced-motion: no-preference)',()=>{
        const hero=document.querySelector<HTMLElement>('.hero-cinematic');
        const art=hero?.querySelector<HTMLElement>('.hero-stage');
        // One opacity writer. Entrance and scroll animate independent values, so
        // neither tween captures the other's partially faded state.
        const state={intro:window.scrollY>100?1:.9,fade:1};
        const paint=()=>{if(art)art.style.opacity=String(state.intro*state.fade);};
        if(hero&&art){
          // Fast reveal, scoped to this HERO. Content is visible without JS.
          const enter=gsap.timeline({defaults:{ease:'power3.out'}});
          enter.to(state,{intro:1,duration:.6,onUpdate:paint},0)
            .fromTo(art,{scale:1.008},{scale:1,duration:.95},0)
            .fromTo(hero.querySelector('.eyebrow'),{opacity:0,y:6},{opacity:1,y:0,duration:.25},0)
            .fromTo(hero.querySelectorAll('.hero-title-line'),{yPercent:105,opacity:0},{yPercent:0,opacity:1,duration:.5,stagger:.04,ease:'power4.out'},0)
            .fromTo(hero.querySelector('.hero-copy h2'),{opacity:0,y:10},{opacity:1,y:0,duration:.4},.58)
            .fromTo(hero.querySelector('.hero-copy p'),{opacity:0,y:8},{opacity:1,y:0,duration:.4},.62)
            .fromTo(hero.querySelector('.hero-buttons'),{opacity:0,y:8},{opacity:1,y:0,duration:.35},.76);
          const sync=(progress:number)=>{
            cinematicState.progress=progress;
            state.fade=1-.95*Math.max(0,(progress-.35)/.65);
            paint();
            gsap.set(art,{y:progress*90});
          };
          ScrollTrigger.create({trigger:hero,start:'top top',end:'bottom top',
            onUpdate:self=>sync(self.progress),onRefresh:self=>sync(self.progress)});
          paint();
        }
        gsap.fromTo('.process-line',{scaleY:0},{scaleY:1,ease:'none',scrollTrigger:{trigger:'.process',start:'top 70%',end:'bottom 80%',scrub:true}});
        gsap.fromTo('.pricing-grid',{scale:.97},{scale:1,ease:'none',scrollTrigger:{trigger:'.pricing',start:'top 85%',end:'top 25%',scrub:1}});
        return()=>{cinematicState.progress=0;if(art){art.style.opacity='';art.style.transform='';}};
      });
    }).catch(()=>{
      // A failed animation chunk must leave the server-rendered content usable.
      cleanup();cinematicState.progress=0;
    });
    return()=>{active=false;cleanup();cinematicState.progress=0;};
  },[]);
  return null;
}
export function PointerEffects() {
  const glow=useRef<HTMLDivElement>(null);
  useEffect(()=>{
    const reduced=matchMedia('(prefers-reduced-motion: reduce)');
    const fine=matchMedia('(pointer:fine)');
    let frame=0;let last:HTMLElement|null=null;let listening=false;
    const refined='.contact-form .button,.cta .button,.service-detail .button';
    const reset=(button:HTMLElement)=>{if(button.matches(refined))button.style.translate='';else button.style.transform='';};
    const leave=()=>{
      cancelAnimationFrame(frame);if(last)reset(last);last=null;
      cinematicState.pointer.x=0;cinematicState.pointer.y=0;
      if(glow.current)glow.current.style.transform='translate3d(-500px,-500px,0)';
    };
    const move=(e:PointerEvent)=>{
      if(reduced.matches||!fine.matches||e.pointerType!=='mouse')return;
      cancelAnimationFrame(frame);frame=requestAnimationFrame(()=>{
        if(reduced.matches||!fine.matches)return;
        cinematicState.pointer.x=e.clientX/innerWidth*2-1;cinematicState.pointer.y=1-e.clientY/innerHeight*2;
        if(glow.current)glow.current.style.transform=`translate3d(${e.clientX}px,${e.clientY}px,0) translate(-50%,-50%)`;
        const button=e.target instanceof Element?e.target.closest<HTMLElement>('.button'):null;
        if(last&&last!==button)reset(last);
        if(button?.matches(':disabled,[aria-disabled="true"]')){reset(button);last=null;return;}
        if(button){const r=button.getBoundingClientRect();
          if(button.matches(refined))button.style.translate=`${Math.max(-2,Math.min(2,(e.clientX-r.left-r.width/2)*.06))}px 0`;
          else button.style.transform=`translate(${Math.max(-5,Math.min(5,(e.clientX-r.left-r.width/2)*.1))}px,${Math.max(-4,Math.min(4,(e.clientY-r.top-r.height/2)*.12))}px)`;
        }
        last=button;
      });
    };
    const update=()=>{
      const enabled=fine.matches&&!reduced.matches;
      if(enabled&&!listening){window.addEventListener('pointermove',move);listening=true;}
      if(!enabled){window.removeEventListener('pointermove',move);listening=false;leave();}
    };
    reduced.addEventListener('change',update);fine.addEventListener('change',update);
    window.addEventListener('blur',leave);document.addEventListener('pointerleave',leave);update();
    return()=>{
      window.removeEventListener('pointermove',move);window.removeEventListener('blur',leave);document.removeEventListener('pointerleave',leave);
      reduced.removeEventListener('change',update);fine.removeEventListener('change',update);leave();
    };
  },[]);
  return <div ref={glow} className="cursor-glow" aria-hidden="true"/>;
}
