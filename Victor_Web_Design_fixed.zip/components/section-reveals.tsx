'use client';
import {useEffect} from 'react';
/** Progressive enhancement: no initial hidden styles and no React frame updates. */
export default function SectionReveals(){
 useEffect(()=>{
  const main=document.getElementById('continut');if(!main||!('IntersectionObserver' in window)||!('animate' in Element.prototype))return;
  const reduced=matchMedia('(prefers-reduced-motion: reduce)');const seen=new WeakSet<Element>();const active=new Map<HTMLElement,Animation>();
  function eligible(el:HTMLElement){if(!el.closest('.section')||el.closest('.hero,.hero-cinematic')||el.closest('[role="status"],[role="alert"],[aria-live]:not([aria-live="off"])'))return false;return el.hasAttribute('data-reveal-card')||!el.closest('[data-reveal-card]');}
  const observer=new IntersectionObserver(entries=>{
   for(const entry of entries){if(!entry.isIntersecting)continue;const el=entry.target as HTMLElement;if(el instanceof HTMLImageElement&&!el.complete)continue;observer.unobserve(el);if(seen.has(el))continue;seen.add(el);if(reduced.matches||!el.isConnected)continue;
    const card=el.hasAttribute('data-reveal-card');const image=el.tagName==='IMG';const title=el.tagName==='H2';
    const duration=card?450:image?550:title?500:400;
    const delay=card?Math.max(0,Math.min(180,Number(el.dataset.revealDelay||0)*1000)):0;
    const frames=image?[{opacity:0},{opacity:1}]:[{opacity:0,transform:'translateY(20px)'},{opacity:1,transform:'translateY(0)'}];
    // Images inside cards have their own opacity-only reveal; parent owns movement.
    const animation=el.animate(frames,{duration,delay,easing:'cubic-bezier(.22,1,.36,1)',fill:'backwards'});active.set(el,animation);
    animation.finished.then(()=>active.delete(el),()=>active.delete(el));
   }
  },{threshold:.08,rootMargin:'0px 0px -24px 0px'});
  const selector='[data-reveal-card],h2,p,img';
  function bind(node:Element){const candidates=[...(node.matches(selector)?[node]:[]),...node.querySelectorAll(selector)];for(const node of candidates){const el=node as HTMLElement;const imageInsideCard=el.tagName==='IMG'&&!!el.closest('[data-reveal-card]');if((eligible(el)||imageInsideCard&&!el.closest('.hero'))&&!seen.has(el))observer.observe(el);}}
  bind(main);
  const loaded=(event:Event)=>{const el=event.target;if(el instanceof HTMLImageElement&&!seen.has(el)&&(eligible(el)||!!el.closest('[data-reveal-card]')&&!!el.closest('.section')&&!el.closest('.hero'))){observer.unobserve(el);observer.observe(el);}};
  main.addEventListener('load',loaded,true);
  const mutations=new MutationObserver(records=>{
   for(const record of records){for(const node of record.addedNodes)if(node instanceof Element)bind(node);for(const node of record.removedNodes)if(node instanceof Element){for(const el of [node,...node.querySelectorAll(selector)])observer.unobserve(el);}}
   for(const [el,animation] of active)if(!el.isConnected){animation.cancel();active.delete(el);}
  });mutations.observe(main,{childList:true,subtree:true});
  const change=()=>{if(reduced.matches){for(const animation of active.values())animation.cancel();active.clear();}};reduced.addEventListener('change',change);
  return()=>{main.removeEventListener('load',loaded,true);observer.disconnect();mutations.disconnect();reduced.removeEventListener('change',change);for(const animation of active.values())animation.cancel();active.clear();};
 },[]);
 return null;
}
