import type { Metadata } from 'next';
export const base = process.env.NEXT_PUBLIC_SITE_URL || 'https://victor-web-design.darktide2.chatgpt.site';
export function meta(title:string,description:string,path:string):Metadata {return {title,description,alternates:{canonical:base+path},openGraph:{title,description,url:base+path,locale:'ro_RO',type:'website',images:[{url:base+'/og.webp',width:1200,height:630}]},twitter:{card:'summary_large_image',title,description,images:[base+'/og.webp']}}}
export function JsonLd({data}:{data:unknown}){return <script type="application/ld+json" dangerouslySetInnerHTML={{__html:JSON.stringify(data).replace(/</g,'\u003c')}}/>}
