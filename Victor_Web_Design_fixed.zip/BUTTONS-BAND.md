# Victor Web Design — butoane și bandă servicii

Modificări locale, fără publicare. Punct de revenire: `bdc419d`.

## Audit și reparații

- Existau deja hover, fundal animat, săgeți, magnetic pointer și banda continuă. Nu s-au adăugat biblioteci sau listeners concurenți.
- Magnetic folosea `transform` cu ±4px vertical și înlocuia hover-ul CSS. Pentru butoanele din Contact, CTA și detalii servicii, folosește acum `translate` separat: ±2px numai orizontal; hover vertical maximum 2px, activ pe touch 1px. Restul butoanelor păstrează comportamentul anterior.
- Tranziții 200ms, fundal 220ms și săgeată 200ms; focus vizibil. Culorile și dimensiunile nu s-au schimbat. Butoanele dezactivate nu se deplasează.
- Banda pornea înainte de măsurare cu distanță implicită. Acum începe numai după măsurarea unui grup complet; distanță exactă și viteză constantă 60px/s. Faza este păstrată la redimensionare/încărcarea fonturilor.
- Hover pauzează numai cu pointer precis care suportă hover, evitând hover persistent pe touch. Pauza manuală, focus, tab ascuns și ieșirea din viewport se păstrează.
- Reduced-motion: fără deplasări ale butoanelor; banda statică, un singur grup vizibil cu text care se împachetează, fără scroll orizontal.
- Cleanup pentru observers și evenimente, fără bucle JS continue în bandă; CSS transform execută animația.

## Verificări

TypeScript, lint și build Next.js; 10 teste Node. Scenarii Playwright pentru bandă, resize și butoane sunt pregătite și listate, neexecutate. Nu există control-browser în mediul Sites: afișarea desktop/mobil, viteza percepută și absența unui salt vizibil nu au fost confirmate în browser.

## Fișiere

`components/service-marquee.tsx`, `components/effects.tsx` (numai PointerEffects), `app/globals.css`, `tests/e2e/motion.spec.ts` și acest raport.

HERO, conținutul Portofoliu/Prețuri, paginile, fonturile, imaginile, culorile și destinațiile linkurilor sunt păstrate. Arhiva include sursa în `ready-project` și previzualizarea HTML în `preview-html/index.html`. Exportul HTML nu include backendul real sau scena Three.js completă.
