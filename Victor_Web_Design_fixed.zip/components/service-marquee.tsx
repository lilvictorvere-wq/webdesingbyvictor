'use client';
import {useEffect,useRef,useState} from 'react';
import {Pause,Play} from 'lucide-react';
const labels=['WEB DESIGN','DEVELOPMENT','SEO & STRATEGIE','EXPERIENȚE DIGITALE'];
export default function ServiceMarquee(){
 const root=useRef<HTMLDivElement>(null);const track=useRef<HTMLDivElement>(null);const [paused,setPaused]=useState(false);
 useEffect(()=>{
  const container=root.current,rail=track.current;if(!container||!rail)return;
  const group=rail.querySelector<HTMLElement>('.marquee-group');if(!group)return;
  let distance=0;
  const measure=()=>{
   const width=group.getBoundingClientRect().width;if(width<=0||Math.abs(width-distance)<.5)return;
   // Keep the loop phase when fonts/viewport resize; start only after measurement.
   const animation=rail.getAnimations().find(item=>'animationName' in item&&item.animationName==='service-band');
   const elapsed=animation&&typeof animation.currentTime==='number'?animation.currentTime:0;
   const phase=distance>0?(elapsed/(distance/60*1000))%1:0;
   distance=width;rail.style.setProperty('--marquee-distance',`${-width}px`);rail.style.setProperty('--marquee-duration',`${width/60}s`);
   rail.dataset.ready='true';
   if(animation)animation.currentTime=phase*(width/60*1000);
  };
  // Unwrap synchronously to measure the intrinsic group; no animation until ready.
  rail.dataset.ready='measuring';
  measure();const resize=new ResizeObserver(measure);resize.observe(group);
  const visibility=new IntersectionObserver(([entry])=>{container.dataset.visible=String(entry.isIntersecting);});visibility.observe(container);
  const state=()=>{container.dataset.hidden=String(document.hidden);};document.addEventListener('visibilitychange',state);state();
  let active=true;document.fonts.ready.then(()=>{if(active)measure();});
  return()=>{active=false;resize.disconnect();visibility.disconnect();document.removeEventListener('visibilitychange',state);delete rail.dataset.ready;};
 },[]);
 return <div ref={root} className="marquee service-marquee" data-paused={paused} aria-label="Specializări">
  <div ref={track} className="marquee-track">{[0,1,2,3].map(copy=><div className="marquee-group" key={copy} aria-hidden={copy>0?'true':undefined}>{labels.map(label=><span className="marquee-item" key={label}><span>{label}</span><i aria-hidden="true">✧</i></span>)}</div>)}</div>
  <button type="button" className="marquee-control" aria-label={paused?'Pornește banda cu servicii':'Oprește banda cu servicii'} aria-pressed={paused} onClick={()=>setPaused(v=>!v)}>{paused?<Play size={15}/>:<Pause size={15}/>}</button>
 </div>;
}
