import type {AnchorHTMLAttributes} from 'react';
/** Native anchors preserve navigation even before hydration or if the SPA router fails. */
export default function SiteLink(props:AnchorHTMLAttributes<HTMLAnchorElement>){return <a {...props}/>;}
