// Mutable frame signals; no React rerender on mouse movement or scroll.
export const cinematicState = { progress: 0, pointer: { x: 0, y: 0 } };
