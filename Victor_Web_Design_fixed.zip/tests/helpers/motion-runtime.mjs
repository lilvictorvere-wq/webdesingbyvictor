import vm from 'node:vm';
import fs from 'node:fs';
import {createRequire} from 'node:module';
import ts from 'typescript';
const require=createRequire(import.meta.url);
export class Events {
 handlers=new Map();
 addEventListener(name,fn){if(!this.handlers.has(name))this.handlers.set(name,new Set());this.handlers.get(name).add(fn);}
 removeEventListener(name,fn){this.handlers.get(name)?.delete(fn);}
 emit(name,data={}){for(const fn of [...(this.handlers.get(name)||[])])fn(data);}
 count(){return [...this.handlers.values()].reduce((sum,set)=>sum+set.size,0);}
}
export function runtime({reduced=false,fine=true,imports={}}={}){
 const win=new Events(),doc=new Events(),motion=new Events(),pointer=new Events();motion.matches=reduced;pointer.matches=fine;
 win.scrollY=0;doc.hidden=false;doc.fonts={ready:Promise.resolve()};const refs=[],effects=[],states=[],frames=new Map();let next=0,stateIndex=0;
 const signal={progress:0,pointer:{x:0,y:0}};
 const React={Component:class{},useEffect:fn=>effects.push(fn),useCallback:fn=>fn,useRef:value=>{const ref={current:refs.length?value:{style:{}}};refs.push(ref);return ref;},useId:()=>':test:',useSyncExternalStore:()=>true,useState:initial=>{const index=stateIndex++;if(!(index in states))states[index]=initial;return [states[index],value=>{states[index]=typeof value==='function'?value(states[index]):value;}];}};
 const sandbox={console,Promise,Map,WeakSet,Set,Math,Number,String,Element:class{static [Symbol.hasInstance](node){return !!node?.closest;}},HTMLElement:class{static [Symbol.hasInstance](node){return !!node?.closest;}},window:win,document:doc,innerWidth:1440,innerHeight:900,matchMedia:query=>query.includes('reduced')?motion:pointer,requestAnimationFrame:fn=>{frames.set(++next,fn);return next;},cancelAnimationFrame:id=>frames.delete(id)};
 function load(file){const text=fs.readFileSync(new URL('../../'+file,import.meta.url),'utf8');const compiled=ts.transpileModule(text,{compilerOptions:{jsx:ts.JsxEmit.ReactJSX,module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022,esModuleInterop:true}}).outputText;const result={exports:{}};
  const localRequire=name=>{if(name in imports)return typeof imports[name]==='function'?imports[name]():imports[name];if(name==='react')return React;if(name==='react/jsx-runtime'||name==='lucide-react')return require(name);if(name==='next/dynamic')return {__esModule:true,default:()=>()=>null};if(name.includes('cinematic-state'))return {cinematicState:signal};if(name.includes('content'))return {services:Array.from({length:6},(_,i)=>({slug:'service-'+i,name:'Serviciul '+i,description:'Descrierea '+i}))};return {__esModule:true,default:()=>null,Reveal:()=>null};};
  vm.runInNewContext(compiled,{...sandbox,module:result,exports:result.exports,require:localRequire},{filename:file});return result.exports;
 }
 return {win,doc,motion,pointer,signal,refs,effects,sandbox,load,render:fn=>{stateIndex=0;return fn();},flush:()=>{const queue=[...frames.values()];frames.clear();queue.forEach(fn=>fn());},frameCount:()=>frames.size};
}
export function nodes(tree,predicate){if(!tree||typeof tree!=='object')return [];const children=tree.props?.children;return [...(predicate(tree)?[tree]:[]),...(Array.isArray(children)?children:[children]).flatMap(child=>Array.isArray(child)?child.flatMap(item=>nodes(item,predicate)):nodes(child,predicate))];}
