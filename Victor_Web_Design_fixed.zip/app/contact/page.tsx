import {meta} from '@/lib/seo';
import Contact from '@/components/contact';
export const dynamic='force-dynamic';
export const metadata=meta('Următorul tău proiect începe aici','Ai un proiect în minte? Spune-ne ce vrei să realizezi.','/contact');
export default function Page(){return <section className="section contact-page" style={{paddingTop:'clamp(32px, 5vw, 64px)'}}>
  <style>{`.contact-page .contact-story h1{font-size:48px;line-height:1.12}@media(max-width:760px){.contact-page .contact-story h1{font-size:44px}}`}</style>
  <Contact deliveryEnabled={!!(process.env.RESEND_API_KEY&&process.env.CONTACT_FROM&&process.env.CONTACT_TO)} email={process.env.CONTACT_EMAIL||process.env.NEXT_PUBLIC_CONTACT_EMAIL} whatsapp={process.env.CONTACT_WHATSAPP||process.env.NEXT_PUBLIC_WHATSAPP}/>
</section>}
