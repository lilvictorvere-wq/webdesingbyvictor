# Victor Web Design

Website în limba română: Next.js App Router, TypeScript, Tailwind CSS, Motion, Three.js / React Three Fiber, GSAP / ScrollTrigger și Lucide.

## Pornire locală

Cerințe: Node.js 22.13+ și pnpm 11.

```bash
pnpm install
cp .env.example .env.local
pnpm dev:next
```

Deschide http://localhost:3000. Pentru producție Next.js: `pnpm build:next`, apoi `pnpm start:next`. Proiectul poate fi instalat pe o platformă cu suport Next.js / Node.js.

## Sites / Cloudflare

Versiunea găzduită folosește Vinext, implementarea API-urilor Next.js pe Vite, și adaptorul Sites pentru Cloudflare Workers. Este aceeași arhitectură App Router, cu build separat. `pnpm dev`, `pnpm build` și `pnpm start` folosesc acest runtime. Nu șterge `sites()` din vite.config.ts. Pentru configurare găzduită, setează variabilele de mediu prin administrarea Site-ului și reconstruiește pentru valorile NEXT_PUBLIC_*.

## Configurare obligatorie

- `NEXT_PUBLIC_SITE_URL`: domeniul final, fără slash final; utilizat de canonical, sitemap și JSON-LD.
- `NEXT_PUBLIC_CONTACT_EMAIL`: email public. `NEXT_PUBLIC_WHATSAPP`: număr internațional cu prefix de țară.
- `NEXT_PUBLIC_INSTAGRAM`, `NEXT_PUBLIC_FACEBOOK`, `NEXT_PUBLIC_LINKEDIN`: URL-uri reale, opționale. Linkurile lipsă sunt ascunse.
- `RESEND_API_KEY`, `CONTACT_FROM`, `CONTACT_TO`: trimitere reală prin API Resend. Adresa FROM trebuie să folosească un domeniu verificat în Resend. Nu publica cheia în cod sau în variabile NEXT_PUBLIC.
- Completează identitatea juridică, datele operatorului și politicile pentru procesele reale înainte de lansarea publică.

Formularul returnează 503 dacă emailul nu este configurat. Nu raportează un succes fictiv. Include validare Zod pe server, verificarea originii, honeypot, timp minim de completare, limită de dimensiune și limită de cereri în memorie. Limita în memorie se resetează la restart și nu este distribuită între Worker isolates; pentru trafic mare adaugă limitare persistentă și Turnstile. Success indică acceptarea mesajului de furnizor, nu livrarea garantată în inbox.

## Editare

`lib/content.ts`: servicii, prețuri, FAQ și proiecte. `app/globals.css`: design și responsive. `components/ancient-scene.tsx`: sculptură, templu și cameră 3D. `public/projects`: imagini WebP originale ale conceptelor demo și galerii.

Portofoliul are șase concepte demo, filtre și pagini individuale; nu reprezintă clienți reali sau rezultate comerciale. Imaginile sunt compoziții demonstrative, nu website-uri externe funcționale.

SEO include metadata pentru rute, canonical, Open Graph, Twitter, sitemap, robots și JSON-LD Organization / ProfessionalService / Service / BreadcrumbList / FAQPage. Indexarea previzualizării private necesită acces; domeniul public final și configurarea accesului sunt pași separați. Google nu garantează rich results pentru FAQ sau alte scheme.

Nu sunt activate Google Analytics sau cookies de marketing. Notificarea informativă folosește localStorage. Orice analytics adăugat ulterior trebuie conectat la gestionarea consimțământului.

## Animații și performanță

Scena 3D se încarcă dinamic pe dispozitive desktop compatibile. Fallback CSS pentru mobil, reduced motion și hardware modest. DPR limitat la 1–1,35, geometrie controlată, scene independente de conținut. Motion pentru reveal / tranziții, GSAP pentru parallax și timeline, tilt și butoane magnetice pe pointer precis. `prefers-reduced-motion` dezactivează efectele relevante.

## Verificări

```bash
pnpm exec tsc --noEmit
pnpm lint
pnpm build
```

Țintele Lighthouse Performance 90+, SEO 95+, Accessibility 90+, Best Practices 90+ trebuie măsurate pe domeniul final. Nu sunt rezultate garantate. Nu a fost disponibilă verificarea vizuală în browser sau o rulare Lighthouse în această sesiune.


## Redesign cinematic monocromatic

Proiectul și rutele existente au fost păstrate. Versiunea publicată anterior folosește Apollo Belvedere (CC0). Noul hero din draft nu îl folosește: vezi HERO-ASSET-BRIEF.md pentru resursele lipsă. Modelul scanat este decimat la 140.000 de triunghiuri, normalizat la 4,5 unități înălțime și comprimat Meshopt (~489 KB). Decoderul este inclus local în bundle; nu se descarcă un decoder Draco extern.

Fișiere relevante:
- `components/ancient-scene.tsx`: Canvas R3F, Drei, model, templu procedural, coloane, nori cu sprite local, particule și panou 3D.
- `components/effects.tsx`: secvență de intrare ~3 secunde, GSAP ScrollTrigger, încărcare dinamică, fallback, hover și gestiunea reduced motion.
- `lib/cinematic-state.ts`: progresul camerei la scroll, fără rerender React la fiecare cadru.
- `public/models/apollo.glb`: scan optimizat inclus în proiect.
- `public/textures/hero-fallback.webp`: randare statică a aceluiași scan pentru WebGL indisponibil / reduced motion; nu înlocuiește scena interactivă pe desktop compatibil.
- `public/textures/temple-fallback.webp`, `cloud.webp`, `digital-panel.webp`: resurse originale create pentru proiect.
- `scripts/assets/compress-model.mjs`: compresie GLB (`node scripts/assets/compress-model.mjs public/models/apollo.glb`).
- `ASSET-LICENSES.md`: proveniența și licențele resurselor.

Pe ecrane sub 600 px, dispozitive cu mai puțin de patru nuclee raportate și la prefers-reduced-motion se folosește randarea statică; navigarea, textele și formularul rămân accesibile. Scenele se opresc când ies din viewport sau tabul este ascuns. Nori volumetrici simplificați cu billboard-uri, fără raymarching costisitor. Scena folosește iluminare în timp real; scanul CC0 nu are materiale PBR de fotogrammetrie sau o rigă articulată. Mâna este în poziția originală a scanului. Pentru o poză exactă cu degetul îndreptat către panou este necesar un model sculptat/rigged separat cu drepturi comerciale. Nu afirmăm fotorealism identic cu imaginea de referință.

Pentru noul hero lipsesc sculptura în poziția corectă și ruinele corintice. Draftul nu este finalizat vizual. Pentru înlocuirea sculpturii, folosește un GLB/GLTF cu UV/normale corecte, licență comercială documentată, maximum ~150.000 triunghiuri desktop și texturi locale compacte. Normalizează originea și scara înainte de a schimba calea din componentă.

Verificarea vizuală în browser, FPS-ul și Lighthouse nu au putut fi măsurate în această sesiune. 60 FPS este o țintă de evaluat pe dispozitiv, nu un rezultat declarat.


## Draft hero — următorul pas

Reconstrucția hero se află în `components/hero-stage.tsx` / `components/cinematic-hero.tsx`. Resursele sunt configurabile, fără substitut generic pentru statuia solicitată. Vezi `HERO-ASSET-BRIEF.md`. Versiunea publicată rămâne anterioară până la furnizarea modelelor și verificarea vizuală.


## Versiune vizibilă publicată după draft

Draftul anterior (versiunea 3) era salvat, fără deployment. Noua versiune publică include `public/hero/cinematic-scene.webp` ca plate scenic în WebGL și poster pentru fallback. Scena are cameră reală, panou 3D, nori, particule și scroll sincronizat; sculptura și ruinele fotorealiste sunt încă reprezentate de imagine, nu de mesh-uri GLB. Vezi HERO-ASSET-BRIEF.md. Imaginile sunt originale generate folosind skill-ul imagegen, nu screenshot-ul website-ului de referință.

### Audit și teste de regresie

Consultați [AUDIT-REPARATII.md](./AUDIT-REPARATII.md) pentru cauze, fișiere și limitele verificării. `npm test` execută verificările API și sursă. `npm run typecheck` și `npm run lint` verifică proiectul. Pentru testele browser, porniți local `npm run dev:next`, instalați browserul Playwright pe calculatorul local și rulați `E2E_BASE_URL=http://localhost:3000 npm run test:e2e`. Suita E2E este pregătită; nu a fost executată în mediul gestionat. Linkurile comerciale folosesc navigare HTML nativă pentru a nu depinde de routerul experimental al găzduirii.

### Reparații după audit

Pagina Contact primește disponibilitatea serviciului de email de la server. Dacă lipsesc `RESEND_API_KEY`, `CONTACT_FROM` sau `CONTACT_TO`, formularul arată explicit indisponibilitatea și nu invită utilizatorul la o trimitere care ar eșua. Configurați cele trei valori în producție, cu domeniu Resend verificat, apoi redeploy. Datele publice `CONTACT_EMAIL` și `CONTACT_WHATSAPP` sunt citite pe server la runtime; valorile `NEXT_PUBLIC_*` rămân alternative la build. Nu expuneți chei API în client.

Protecția persistentă împotriva trimiterilor repetate se activează dacă sunt configurate ambele variabile `UPSTASH_REDIS_REST_URL` și `UPSTASH_REDIS_REST_TOKEN`. Contorul folosește hash-ul IP-ului și expiră după zece minute. Dacă serviciul configurat eșuează, trimiterea este refuzată temporar; nu se ocolește protecția. Fără acest serviciu, limita locală per isolate rămâne activă.

Headerele de securitate sunt declarate în `next.config.ts`; CSP este în mod Report-Only, pentru a evita blocarea animațiilor/hidratării fără testare browser. Nu reprezintă încă o politică CSP impusă. Scenele compacte urmăresc resize, reduced motion și vizibilitatea și reiau explicit randarea. Importurile Drei au fost restrânse la modulele folosite.

Rămân de furnizat: identitatea juridică și datele pentru politicile comerciale, configurarea emailului și modelele GLB licențiate pentru statuie/ruine, dacă se dorește înlocuirea compoziției fotografice. Documentele provizorii nu sunt prezentate ca politici juridice finale. Nu s-au executat Lighthouse, FPS sau browser QA în mediul gestionat.
