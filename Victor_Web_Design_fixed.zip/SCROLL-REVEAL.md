# Scroll Reveal — versiune locală nepublicată

Titluri: 500ms. Texte: opacity 0→1, translateY 20px→0, 400ms. Carduri: 450ms și decalaj 60ms între elemente din același rând. Imagini: tranziție opacity 550ms după încărcare, fără a suprascrie zoom-ul de hover.

Un singur IntersectionObserver pentru secțiunile .section; HERO exclus explicit. Elementele sunt vizibile în HTML fără JavaScript. O singură executare per element, fallback fără Web Animations API, anulare la reduced motion și demontare. MutationObserver gestionează filtrele portofoliului fără scanări pe fiecare frame. Fără pachete noi și fără top/left animat.

Problema corectată: Reveal folosea initial opacity 0 în SSR, lăsând conținutul ascuns dacă JavaScript nu pornea. Acum wrapper-ele păstrează conținutul vizibil, iar mișcarea este adăugată după intrarea în viewport. Textele interne cardurilor nu primesc un al doilea reveal; imaginile au doar fade propriu. Animațiile existente de timeline, pricing, hover și HERO sunt păstrate.

Fișiere de cod modificate: app/layout.tsx, components/effects.tsx (doar Reveal), components/sections.tsx, components/portfolio.tsx. Fișier nou: components/section-reveals.tsx. Teste noi: tests/e2e/section-reveals.spec.ts.

Executat și trecut: TypeScript, lint, build Next.js, 10 teste API/sursă, verificare SSR a celor 25 wrapper-e fără opacity 0, verificare comparativă că ScrollEffects/HERO sunt nemodificate, verificare sintaxă JS pentru preview. 19 scenarii Playwright au fost listate, fără execuție browser. Desktop/mobil, consola runtime, suprapunerile și FPS nu au fost verificate vizual.

Pentru preview static: dezarhivează și deschide preview-html/index.html. Acest preview folosește imaginea cinematică; proiectul complet cu WebGL este în ready-project/. Formularul nu trimite email fără configurarea backend-ului. Nu a fost publicat website-ul.
