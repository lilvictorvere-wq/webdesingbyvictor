import {test} from 'node:test';import assert from 'node:assert/strict';import {contactRateLimit} from '../lib/rate-limit.mjs';
test('limita locală expiră după zece minute',async()=>{for(let i=0;i<5;i++)assert.equal((await contactRateLimit('expiry-test',1000)).allowed,true);assert.equal((await contactRateLimit('expiry-test',1000)).status,429);assert.equal((await contactRateLimit('expiry-test',602000)).allowed,true);});
test('configurare incompletă nu permite ocolirea limitei',async()=>{process.env.UPSTASH_REDIS_REST_URL='https://redis.example.test';try{assert.equal((await contactRateLimit('test')).status,503);}finally{delete process.env.UPSTASH_REDIS_REST_URL;}});
test('contor persistent și eroare de serviciu: mock doar în test',async()=>{
 process.env.UPSTASH_REDIS_REST_URL='https://redis.example.test';process.env.UPSTASH_REDIS_REST_TOKEN='test';const original=globalThis.fetch;
 try{globalThis.fetch=async(url,init)=>{assert.equal(url,'https://redis.example.test/pipeline');const commands=JSON.parse(init.body);assert.ok(!commands[0][1].includes('private-ip'));return Response.json([{result:6},{result:1}]);};assert.equal((await contactRateLimit('private-ip')).status,429);globalThis.fetch=async()=>{throw new Error('offline');};assert.equal((await contactRateLimit('test')).status,503);}
 finally{globalThis.fetch=original;delete process.env.UPSTASH_REDIS_REST_URL;delete process.env.UPSTASH_REDIS_REST_TOKEN;}
});
