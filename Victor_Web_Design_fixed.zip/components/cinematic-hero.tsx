'use client';
import {Component,useCallback,useEffect,useRef,useState} from 'react';
import type {ReactNode} from 'react';
import dynamic from 'next/dynamic';
import Image from 'next/image';
import {heroConfig} from '@/lib/hero-config';
const Stage=dynamic(()=>import('./hero-stage'),{ssr:false});
class Boundary extends Component<{children:ReactNode,onFailure:()=>void},{failed:boolean}>{state={failed:false};static getDerivedStateFromError(){return {failed:true};}componentDidCatch(){this.props.onFailure();}render(){return this.state.failed?null:this.props.children;}}
export default function CinematicHero(){const [enabled,setEnabled]=useState(false);const [ready,setReady]=useState(false);const root=useRef<HTMLDivElement>(null);const onReady=useCallback(()=>setReady(true),[]);const onFailure=useCallback(()=>{setReady(false);setEnabled(false);},[]);
 useEffect(()=>{
   const motion=matchMedia('(prefers-reduced-motion: reduce)');
   const desktop=matchMedia('(min-width:700px)');
   let supported=false;
   try{const ctx=document.createElement('canvas').getContext('webgl2');supported=!!ctx;ctx?.getExtension('WEBGL_lose_context')?.loseContext();}catch{}
   const update=()=>{const next=supported&&!motion.matches&&desktop.matches&&(navigator.hardwareConcurrency||4)>=4;setEnabled(next);if(!next)setReady(false);};
   const frame=requestAnimationFrame(update);
   motion.addEventListener('change',update);desktop.addEventListener('change',update);
   return()=>{cancelAnimationFrame(frame);motion.removeEventListener('change',update);desktop.removeEventListener('change',update);};
 },[]);
 useEffect(()=>{const canvas=root.current?.querySelector('canvas');if(!canvas)return;const lost=(e:Event)=>{e.preventDefault();onFailure();};canvas.addEventListener('webglcontextlost',lost);return()=>canvas.removeEventListener('webglcontextlost',lost);},[ready,onFailure]);
 return <div ref={root} className={'hero-art hero-stage'+(ready?' scene-ready':'')} aria-hidden="true"><div className="hero-atmosphere"/>{heroConfig.fallbackUrl&&<div className="ancient-fallback scenic-poster"><Image src={heroConfig.fallbackUrl} alt="" fill priority sizes="100vw"/></div>}{enabled&&<Boundary onFailure={onFailure}><div className="canvas-layer"><Stage onReady={onReady}/></div></Boundary>}</div>;
}
