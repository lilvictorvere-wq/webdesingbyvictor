'use client';
import {Suspense,useEffect,useMemo,useRef} from 'react';
import {Canvas,useFrame,useThree} from '@react-three/fiber';
import {Cloud,Clouds} from '@react-three/drei/core/Cloud';
import {Line} from '@react-three/drei/core/Line';
import {Sparkles} from '@react-three/drei/core/Sparkles';
import {useGLTF} from '@react-three/drei/core/Gltf';
import {useTexture} from '@react-three/drei/core/Texture';
import * as THREE from 'three';
import {heroConfig} from '@/lib/hero-config';
import {cinematicState} from '@/lib/cinematic-state';

function LicensedAsset({url,height,position,yaw,statue=false}:{url:string,height:number,position:[number,number,number],yaw:number,statue?:boolean}) {
  const {scene}=useGLTF(url,false);
  const asset=useMemo(()=>{
    const object=scene.clone(true);
    const bounds=new THREE.Box3().setFromObject(object);const size=bounds.getSize(new THREE.Vector3());
    const scale=height/Math.max(.01,size.y);const center=bounds.getCenter(new THREE.Vector3());
    object.position.set(-center.x,-bounds.min.y,-center.z);
    const holder=new THREE.Group();holder.add(object);holder.scale.setScalar(scale);
    const owned:THREE.Material[]=[];
    object.traverse(child=>{if(child instanceof THREE.Mesh){
      child.castShadow=true;child.receiveShadow=true;
      // Preserve the asset's normal/roughness/AO maps and UVs, neutralize only hue.
      const replace=(original:THREE.Material)=>{
        const source=original as THREE.MeshStandardMaterial;
        const material=new THREE.MeshPhysicalMaterial({color:statue?'#E5E5E5':'#888888',roughness:source.roughness??.75,metalness:statue?.015:.03,normalMap:source.normalMap,roughnessMap:source.roughnessMap,aoMap:source.aoMap,aoMapIntensity:1.15,clearcoat:statue?.04:0});
        owned.push(material);return material;
      };
      child.material=Array.isArray(child.material)?child.material.map(replace):replace(child.material);
    }});
    return {holder,owned};
  },[scene,height,statue]);
  useEffect(()=>()=>asset.owned.forEach(m=>m.dispose()),[asset]);
  return <primitive object={asset.holder} position={position} rotation={[0,yaw,0]} dispose={null}/>;
}

/** Photographic scenery plate, explicitly not a sculpted 3D statue mesh. */
function ScenicPlate(){const texture=useTexture(heroConfig.scenicPlateUrl);return <mesh position={[0,0,-4.2]}><planeGeometry args={[23.6,13.27]}/><meshBasicMaterial map={texture} toneMapped={false}/></mesh>;}

function Panel(){
  const group=useRef<THREE.Group>(null);const texture=useTexture('/textures/digital-panel.webp');
  useFrame(({clock},dt)=>{const pointer=cinematicState.pointer;if(!group.current)return;const d=1-Math.exp(-Math.min(dt,.04)*2);const t=clock.elapsedTime;
    const enter=THREE.MathUtils.smoothstep(t,2.4,3.2);
    group.current.position.x=THREE.MathUtils.lerp(group.current.position.x,5.25+pointer.x*.12,d);
    group.current.position.y=THREE.MathUtils.lerp(group.current.position.y,-.7+(1-enter)*-.7+Math.sin(t*.42)*.08+cinematicState.progress*.18,d);
    group.current.rotation.y=THREE.MathUtils.lerp(group.current.rotation.y,-.3+pointer.x*.03,d);
  });
  return <group ref={group} position={[5.25,-1.4,1.4]} rotation={[.05,-.3,-.06]}>
    <mesh castShadow><boxGeometry args={[3.12,2.07,.09]}/><meshStandardMaterial color="#333333" metalness={.65} roughness={.28}/></mesh>
    <mesh position={[0,0,.051]}><planeGeometry args={[2.99,1.87]}/><meshBasicMaterial map={texture} toneMapped={false}/></mesh>
    <mesh position={[1.05,-.87,.05]}><sphereGeometry args={[.016,8,8]}/><meshBasicMaterial color="#E5E5E5"/></mesh>
  </group>;
}
function CameraRig(){
  const {gl,setFrameloop,invalidate}=useThree();const elapsed=useRef(0);
  useEffect(()=>{let visible=true;const update=()=>{const running=visible&&!document.hidden;setFrameloop(running?'always':'demand');if(running)invalidate();};const observer=new IntersectionObserver(([e])=>{visible=e.isIntersecting;update();});observer.observe(gl.domElement.closest('.hero-cinematic')||gl.domElement);document.addEventListener('visibilitychange',update);return()=>{observer.disconnect();document.removeEventListener('visibilitychange',update);};},[gl,setFrameloop,invalidate]);
  useFrame(({camera},raw)=>{const pointer=cinematicState.pointer;const dt=Math.min(raw,.04);elapsed.current+=dt;const d=1-Math.exp(-dt*2);
    const enter=THREE.MathUtils.smoothstep(elapsed.current,.6,3.2);const p=cinematicState.progress;
    camera.position.x=THREE.MathUtils.lerp(camera.position.x,.4+pointer.x*.13+p*.2,d);
    camera.position.y=THREE.MathUtils.lerp(camera.position.y,.1+pointer.y*.08,d);
    camera.position.z=THREE.MathUtils.lerp(camera.position.z,12.1+(1-enter)*.65-p*.45,d);
    camera.lookAt(.25,.05,0);
  });return null;
}
function Illumination(){const key=useRef<THREE.DirectionalLight>(null);const rim=useRef<THREE.DirectionalLight>(null);const elapsed=useRef(0);
  useFrame((_,raw)=>{elapsed.current+=Math.min(raw,.04);const t=THREE.MathUtils.smoothstep(elapsed.current,0,1.6);if(key.current)key.current.intensity=.03+t*2.65;if(rim.current)rim.current.intensity=.03+t*2.9;});
  return <><ambientLight intensity={.12}/><directionalLight ref={key} castShadow position={[-3,6,5]} intensity={.03} color="#FFFFFF" shadow-mapSize={[1024,1024]} shadow-camera-left={-7} shadow-camera-right={7} shadow-camera-top={8} shadow-camera-bottom={-6} shadow-bias={-.0004} shadow-normalBias={.015}/><directionalLight ref={rim} position={[4,5,-3]} intensity={.03} color="#E5E5E5"/><directionalLight position={[3,0,5]} intensity={.2} color="#888888"/></>;
}
function Background(){
  const group=useRef<THREE.Group>(null);
  const orbit=useMemo(()=>Array.from({length:120},(_,i)=>{const a=i/119*Math.PI*2;return new THREE.Vector3(Math.cos(a)*4.7,Math.sin(a)*4.7,-4.4);}),[]);
  useFrame((_,dt)=>{const pointer=cinematicState.pointer;if(group.current){const d=1-Math.exp(-Math.min(dt,.04)*1.5);group.current.position.x=THREE.MathUtils.lerp(group.current.position.x,-pointer.x*.08-cinematicState.progress*.18,d);}});
  return <group ref={group}>{heroConfig.statueUrl&&<mesh position={[.3,.7,-5.6]}><sphereGeometry args={[4.2,64,48]}/><meshStandardMaterial color="#111111" roughness={.93}/></mesh>}<Line points={orbit} rotation={[.15,.3,-.3]} color="#888888" opacity={.32} transparent lineWidth={.6}/><Sparkles count={52} scale={[12,9,5]} size={1.2} speed={.06} opacity={.4} color="#FFFFFF"/><Clouds texture="/textures/cloud.webp" limit={40} material={THREE.MeshLambertMaterial}><Cloud seed={30} position={[1,-3.3,2]} bounds={[5,1,2]} segments={18} volume={2.7} speed={.025} opacity={.36} color="#888888"/><Cloud seed={64} position={[4,3,-5]} bounds={[4,1.4,1]} segments={16} volume={2.8} speed={.018} opacity={.32} color="#E5E5E5"/></Clouds></group>;
}
function LoadedWorld({onReady}:{onReady:()=>void}){useEffect(()=>{onReady();},[onReady]);return <><CameraRig/><Illumination/><Background/>{!heroConfig.statueUrl&&!heroConfig.ruinsUrl&&<ScenicPlate/>}{heroConfig.statueUrl&&<LicensedAsset url={heroConfig.statueUrl} {...heroConfig.statue} statue/>}{heroConfig.ruinsUrl&&<LicensedAsset url={heroConfig.ruinsUrl} {...heroConfig.ruins}/>}<Panel/><mesh rotation={[-Math.PI/2,0,0]} position={[0,-4.1,0]} receiveShadow><planeGeometry args={[24,22]}/><shadowMaterial transparent opacity={.3}/></mesh></>;}
export default function HeroStage({onReady}:{onReady:()=>void}){return <Canvas shadows="soft" dpr={[1,1.3]} camera={{position:[.4,.1,12.75],fov:43}} gl={{alpha:true,antialias:true,powerPreference:'high-performance'}} onCreated={({gl})=>{gl.toneMapping=THREE.ACESFilmicToneMapping;gl.toneMappingExposure=.85;gl.setClearColor('#050505',0);}}><fog attach="fog" args={['#050505',16,31]}/><Suspense fallback={null}><LoadedWorld onReady={onReady}/></Suspense></Canvas>;}
