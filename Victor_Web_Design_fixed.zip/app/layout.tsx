import type {Metadata} from 'next';
import './globals.css';
import SectionReveals from '@/components/section-reveals';
import {PointerEffects} from '@/components/effects';
import {Header,Footer,CookieNotice} from '@/components/shell';
import {base,JsonLd,meta} from '@/lib/seo';
export const metadata:Metadata={...meta('Victor Web Design — Website-uri premium & SEO','Creare site web, magazine online și web design profesional în România. Design personalizat, experiențe responsive și SEO tehnic.','/'),metadataBase:new URL(base),title:{default:'Victor Web Design — Website-uri premium & SEO',template:'%s | Victor Web Design'},icons:{icon:'/favicon.svg'}};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="ro"><body><a href="#continut" className="skip-link">Sari la conținut</a><Header/><PointerEffects/><main id="continut">{children}</main><Footer/><CookieNotice/><SectionReveals/><JsonLd data={{'@context':'https://schema.org','@graph':[{'@type':'Organization','@id':base+'/#organization',name:'Victor Web Design',url:base,logo:base+'/favicon.svg'},{'@type':'ProfessionalService','@id':base+'/#service',name:'Victor Web Design',url:base,description:'Creare website-uri, web design și optimizare SEO.',areaServed:{'@type':'Country',name:'România'},priceRange:'799 RON – ofertă personalizată'}]}}/></body></html>}
