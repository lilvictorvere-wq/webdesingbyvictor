import {test} from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import path from 'node:path';
import {services,projects} from '../lib/content.ts';
function files(dir){return fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?files(path.join(dir,e.name)):[path.join(dir,e.name)]);}
const source=files('app').concat(files('components').filter(p=>!p.includes('/ui/'))).filter(p=>p.endsWith('.tsx'));
const routes=new Set(['/',...files('app').filter(p=>p.endsWith('/page.tsx')&&!p.includes('[')).map(p=>'/'+p.slice(4,-9)),...services.map(s=>'/'+s.slug),...projects.map(p=>'/portofoliu/'+p.slug)]);
test('destinațiile locale declarate există',()=>{
 for(const file of source){const text=fs.readFileSync(file,'utf8');for(const [,href] of text.matchAll(/href="(\/[^"{}]*)"/g)){const route=href.split(/[?#]/)[0];assert.ok(routes.has(route),`${file}: ${href}`);}}
});
test('resursele portofoliului și imaginile declarate există',()=>{
 for(const project of projects){for(const image of [project.image,`/projects/${project.slug}-1.webp`,`/projects/${project.slug}-2.webp`])assert.ok(fs.existsSync('public'+image),image);}
 for(const file of source){for(const [,image] of fs.readFileSync(file,'utf8').matchAll(/(?:src|texture)="(\/[^"{}]+)"/g))assert.ok(fs.existsSync('public'+image),`${file}: ${image}`);}
 for(const image of ['/hero/cinematic-scene.webp','/textures/cloud.webp','/textures/digital-panel.webp','/og.webp'])assert.ok(fs.existsSync('public'+image),image);
});
test('pachetele și proiectele păstrează toate destinațiile reale',()=>{assert.equal(projects.length,6);assert.equal(services.length,6);for(const project of projects)assert.ok(routes.has('/portofoliu/'+project.slug));});
