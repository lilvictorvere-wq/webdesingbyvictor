import {test,expect} from '@playwright/test';
const widths=[375,390,768,1024,1440,1920];
for(const width of widths){
 test(`Homepage, scroll reversibil și navigare — ${width}px`,async({page})=>{
  await page.setViewportSize({width,height:900});
  const errors:string[]=[];
  page.on('pageerror',e=>errors.push(e.message));
  page.on('console',m=>{if(m.type()==='error'&&/hydrat|uncaught/i.test(m.text()))errors.push(m.text());});
  await page.goto('/');await expect(page.locator('h1')).toContainText('VICTOR');
  const hero=page.locator('.hero-stage');const poster=page.locator('.scenic-poster img');
  await expect(poster).toBeVisible();
  await expect.poll(()=>poster.evaluate((el:HTMLImageElement)=>el.complete&&el.naturalWidth>0)).toBe(true);
  await expect.poll(()=>hero.evaluate(el=>Number(getComputedStyle(el).opacity))).toBeGreaterThan(.98);
  for(let i=0;i<5;i++){
   await page.evaluate(()=>scrollTo(0,innerHeight*1.6));await page.waitForTimeout(250);
   await page.evaluate(()=>scrollTo({top:0,behavior:'instant'}));
   await expect.poll(()=>hero.evaluate(el=>Number(getComputedStyle(el).opacity))).toBeGreaterThan(.98);
   await expect(poster).toBeVisible();
  }
  expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
  await page.getByRole('link',{name:'Vezi proiectele',exact:true}).click();
  await expect(page).toHaveURL(/#proiecte$/);
  await page.locator('.project-card-link').first().click();await expect(page).toHaveURL(/\/portofoliu\/.+/);
  await page.goBack();await expect(page.locator('#proiecte')).toBeVisible();
  await page.goBack();await page.goto('/');
  await page.locator('.hero-buttons').getByRole('link',{name:'Solicită o ofertă'}).click();
  await expect(page.locator('#formular')).toBeVisible();
  if(width<1000){
   const toggle=page.getByRole('button',{name:'Deschide meniul'});
   if(await toggle.isVisible()){
    await toggle.click();await expect(toggle).toHaveAttribute('aria-expanded','true');
    await page.locator('#mobile-navigation').getByRole('link',{name:'Portofoliu'}).click();
    await expect(page).toHaveURL(/\/portofoliu$/);
   }
  }
  expect(errors).toEqual([]);
 });
}
test('Toate rutele interne și resursele locale',async({page,request})=>{
 await page.goto('/');
 const hrefs=await page.locator('a[href^="/"]').evaluateAll(els=>[...new Set(els.map(el=>el.getAttribute('href')!))]);
 for(const href of hrefs){const response=await request.get(href);expect(response.status(),href).toBe(200);}
 await page.goto('/portofoliu');
 const projects=await page.locator('.project-card-link').evaluateAll(els=>els.map(el=>el.getAttribute('href')!));
 expect(projects).toHaveLength(6);
 for(const href of projects){await page.goto(href);await expect(page.locator('h1')).toBeVisible();for(const img of await page.locator('img').all()){await expect.poll(()=>img.evaluate((el:HTMLImageElement)=>el.complete&&el.naturalWidth>0)).toBe(true);}}
});
test('Pachete precompletate și formular: validare, eroare, succes real confirmat',async({page})=>{
 for(const plan of ['Starter','Business','Premium']){
  await page.goto('/preturi');await page.locator(`a[href="/contact?pachet=${plan}#formular"]`).click();
  await expect(page.locator('select[name="budget"]')).toHaveValue(plan);
 }
 expect(await page.locator('form').evaluate((el:HTMLFormElement)=>el.checkValidity())).toBe(false);
 if(await page.getByRole('button',{name:'Trimite solicitarea'}).isDisabled()){await expect(page.locator('.contact-availability')).toContainText('momentan indisponibilă');return;}
 await page.getByRole('button',{name:'Trimite solicitarea'}).click();
 await page.locator('[name="name"]').fill('Test QA');await page.locator('[name="email"]').fill('qa@example.com');
 await page.locator('[name="type"]').selectOption('Website de prezentare');await page.locator('[name="message"]').fill('Solicitare demonstrativă pentru testarea formularului.');await page.locator('[name="consent"]').check();
 // Stub only in automated QA; production never simulates successful delivery.
 await page.route('**/api/contact',r=>r.fulfill({status:503,json:{message:'Trimiterea nu este configurată încă.'}}));
 await page.getByRole('button',{name:'Trimite solicitarea'}).click();await expect(page.getByRole('status')).toContainText('nu este configurată');
 await expect(page.locator('[name="name"]')).toHaveValue('Test QA');
 await page.unroute('**/api/contact');await page.route('**/api/contact',r=>r.fulfill({status:200,json:{message:'Mesajul tău a fost trimis.'}}));
 await page.getByRole('button',{name:'Trimite solicitarea'}).click();await expect(page.getByRole('status')).toContainText('a fost trimis');
 await expect(page.locator('[name="name"]')).toHaveValue('');
});
test('Mișcare redusă și resize păstrează fallback-ul',async({page})=>{
 await page.emulateMedia({reducedMotion:'reduce'});await page.goto('/');
 await expect(page.locator('.scenic-poster img')).toBeVisible();
 await page.setViewportSize({width:390,height:844});await expect(page.locator('.scenic-poster img')).toBeVisible();
 await page.emulateMedia({reducedMotion:'no-preference'});await page.setViewportSize({width:1440,height:900});
 await expect(page.locator('.scenic-poster img')).toBeVisible();
});
