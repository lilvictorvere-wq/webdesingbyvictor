import {test,expect} from '@playwright/test';
for(const width of [375,768,1440]){
 test(`Reveal secțiuni, filtre și linkuri — ${width}px`,async({page})=>{
  await page.setViewportSize({width,height:900});const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
  await page.goto('/');await page.locator('#servicii').scrollIntoViewIfNeeded();
  const card=page.locator('#servicii [data-reveal-card]').first();
  await expect.poll(()=>card.evaluate(el=>getComputedStyle(el).opacity)).toBe('1');
  await page.waitForTimeout(800);
  expect(await card.evaluate(el=>el.getAnimations().length)).toBe(0);
  await card.getByRole('button').click();await card.getByRole('link',{name:'Descoperă serviciul'}).click();await expect(page).toHaveURL(/\/creare-site-web$/);
  await page.goto('/portofoliu');await page.getByRole('button',{name:'Magazine online',exact:true}).click();
  await expect(page.locator('.project-card-link')).toHaveCount(2);
  await page.waitForTimeout(900);await page.locator('.project-card-link').first().click();await expect(page).toHaveURL(/\/portofoliu\/aura-store$/);
  expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);expect(errors).toEqual([]);
 });
}
test('Fără JavaScript: cardurile și textele sunt vizibile',async({browser})=>{
 const context=await browser.newContext({javaScriptEnabled:false});const page=await context.newPage();
 await page.goto(process.env.E2E_BASE_URL||'http://localhost:3000');
 for(const selector of ['#servicii [data-reveal-card]','#proiecte [data-reveal-card]','#preturi [data-reveal-card]']){
  await expect(page.locator(selector).first()).toHaveCSS('opacity','1');await expect(page.locator(selector).first()).toBeVisible();
 }
 await context.close();
});
test('Reduced motion: conținutul rămâne vizibil și fără animații reveal',async({page})=>{
 await page.emulateMedia({reducedMotion:'reduce'});await page.goto('/');
 await page.locator('#servicii').scrollIntoViewIfNeeded();
 const card=page.locator('#servicii [data-reveal-card]').first();await expect(card).toHaveCSS('opacity','1');
 expect(await card.evaluate(el=>el.getAnimations().length)).toBe(0);
});
