export default function Loading(){return <div className="loading" role="status"><span className="loading-orb"/><p>Pregătim experiența…</p></div>}
