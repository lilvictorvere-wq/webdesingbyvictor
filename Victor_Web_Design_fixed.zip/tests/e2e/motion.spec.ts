import {test,expect} from '@playwright/test';
for(const width of [375,768,1440,1920]){
 test(`Banda continuă și controalele — ${width}px`,async({page})=>{
  await page.setViewportSize({width,height:900});await page.goto('/');
  const band=page.locator('.service-marquee');await band.scrollIntoViewIfNeeded();await page.mouse.move(0,0);
  const rail=band.locator('.marquee-track');
  await expect.poll(()=>rail.evaluate(el=>getComputedStyle(el).animationName)).toBe('service-band');
  await expect.poll(()=>rail.evaluate(el=>getComputedStyle(el).animationPlayState)).toBe('running');
  const start=await rail.evaluate(el=>getComputedStyle(el).transform);await page.waitForTimeout(300);
  expect(await rail.evaluate(el=>getComputedStyle(el).transform)).not.toBe(start);
  await band.getByRole('button',{name:'Oprește banda cu servicii'}).click();
  await expect(band.getByRole('button')).toHaveAttribute('aria-pressed','true');
  await page.mouse.move(0,0);await expect.poll(()=>rail.evaluate(el=>getComputedStyle(el).animationPlayState)).toBe('paused');
  await band.getByRole('button',{name:'Pornește banda cu servicii'}).click();await page.mouse.move(0,0);
  await page.locator('.header').click({position:{x:2,y:45}});await expect.poll(()=>rail.evaluate(el=>getComputedStyle(el).animationPlayState)).toBe('running');
  expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
  await page.locator('.project-card-link').first().scrollIntoViewIfNeeded();
  await expect(page.locator('.project-card-link').first()).toBeVisible();
  await page.locator('.project-card-link').first().click();await expect(page).toHaveURL(/\/portofoliu\/.+/);
 });
}
test('Mișcare redusă: banda rămâne statică și lizibilă',async({page})=>{
 await page.emulateMedia({reducedMotion:'reduce'});await page.goto('/');
 await expect(page.locator('.marquee-track')).toHaveCSS('animation-name','none');
 await expect(page.locator('.marquee-control')).toBeHidden();
 await expect(page.locator('.marquee-group').first()).toContainText('WEB DESIGN');
});

test('Banda păstrează distanța exactă și pauza după resize',async({page})=>{
 await page.goto('/');const band=page.locator('.service-marquee');await band.scrollIntoViewIfNeeded();await page.mouse.move(0,0);
 const track=band.locator('.marquee-track');await expect(track).toHaveAttribute('data-ready','true');
 for(const width of [390,768,1440,1920]){
  await page.setViewportSize({width,height:900});
  await expect.poll(()=>track.evaluate(el=>Math.abs(parseFloat((el as HTMLElement).style.getPropertyValue('--marquee-distance'))+el.querySelector('.marquee-group')!.getBoundingClientRect().width))).toBeLessThan(.5);
 }
 await band.getByRole('button').click();await page.setViewportSize({width:1024,height:900});await expect(track).toHaveCSS('animation-play-state','paused');
});
test('CTA servicii: hover limitat, focus vizibil și destinație păstrată',async({page})=>{
 await page.goto('/creare-site-web');const button=page.locator('.service-detail .button');
 await button.scrollIntoViewIfNeeded();await button.hover();await page.waitForTimeout(300);
 expect(await button.evaluate(el=>Math.abs(new DOMMatrix(getComputedStyle(el).transform).m42))).toBeLessThanOrEqual(2);
 await button.focus();await expect(button).toHaveCSS('outline-style','solid');
 await button.click();await expect(page).toHaveURL(/\/contact/);
});
