# Hero cinematic — versiune vizuală publicată, GLB-uri încă necesare

## Stare

Hero-ul publicat folosește o compoziție scenică originală generată prin imagegen, mult mai apropiată vizual de referință. Aceasta este randată ca plan texturat în scena WebGL; nu este un GLB sculptat al personajului. Camera 3D, panoul digital, particulele, cercurile și norii sunt interactive și randate separat. Fallback-ul fără WebGL folosește aceeași imagine în HTML. Nu sunt folosite modelele geometrice simplificate pentru sculptură sau ruine.

Reproducerea integrală 3D nu este finalizată: pentru parallax complet în jurul personajului și iluminare dinamică pe marmură sunt necesare GLB-urile de mai jos. Trecerea la ele este configurabilă. Celelalte secțiuni și API-ul nu au fost schimbate.

## Sculptură necesară

Furnizează `public/models/hero-statue.glb`, cu dovada licenței comerciale / CC0 sau drepturi de autor proprii.

Personaj masculin antic, proporții anatomice realiste, expresie solemnă, păr ondulat sculptat și draperie bogată care curge de la umăr către baza statuii. Brațul drept al personajului trebuie sculptat întins în sus și spre dreapta imaginii, un unghi de aproximativ 20–35° peste orizontală. Mâna indică panoul digital din dreapta. Nu este suficientă rotirea întregului corp sau un bust. Modelul din referință este o direcție vizuală, nu un GLB extras din imagine.

Livrare recomandată: Y-up, fața orientată spre +Z, origine la bază, 100k–200k triunghiuri pentru desktop, normale smooth cu detalii sculpturale păstrate. UV-uri valide; normal, roughness și AO maps locale maximum 2048×2048. Texturi monocromatice. Evită texturi cu lumini deja pictate. Compresie Meshopt prin scriptul inclus. Dacă se folosesc maps AO, trebuie să existe atributele UV corespunzătoare. Modelul trebuie verificat vizual înainte de utilizare.

## Arhitectură necesară

Furnizează `public/models/corinthian-ruins.glb`, cu licență adecvată: coloane corintice cu frunze de acant și volute detaliate, entablatură / arc de ruină, piatră deteriorată natural. Se recomandă scan / fotogrammetrie cu materiale PBR monocromatice și niveluri de detaliu. În noul hero nu sunt folosite coloanele cilindrice simplificate din scena anterioară.

## Configurare

În `.env.local`, apoi rebuild:

```env
NEXT_PUBLIC_HERO_STATUE_URL=/models/hero-statue.glb
NEXT_PUBLIC_HERO_RUINS_URL=/models/corinthian-ruins.glb
NEXT_PUBLIC_HERO_FALLBACK_URL=/textures/hero-final-poster.webp
```

`hero-final-poster.webp` trebuie randat din scena finală pentru reduced motion / mobile; nu folosi screenshot-ul complet al referinței cu texte sau statistici inventate.

`lib/hero-config.ts` definește poziția, orientarea și înălțimea resurselor. Normalizarea GLB se face după bounding box, fără deformarea proporțiilor. După introducerea modelelor, ajustează transformările în raport cu captura reală.

## Cod și animație

- `components/hero-stage.tsx`: R3F / Drei, model GLB, panou independent, nori, orbită, lumină laterală și rim, umbre PCF soft, ACES, damping și camera la scroll.
- `components/cinematic-hero.tsx`: import dinamic, reduced motion, fallback configurabil, tratare erori de încărcare și context WebGL pierdut.
- `components/effects.tsx`: intrare GSAP aproximativ 3,2 secunde și ScrollTrigger natural.
- `app/globals.css`: numai reguli finale `.hero-cinematic` pentru 40% text / 35% sculptură / 25% arhitectură. Canvas-ul este limitat la partea dreaptă, pentru a nu acoperi titlul.

Materialul GLB păstrează maps normal / roughness / AO. Color maps sunt neutralizate pentru a evita nuanțele. AO necesită maps reale; nu sunt inventate date de ocluzie pentru un model absent. Umbrele sunt activate numai pentru geometria încărcată.

## Verificare necesară înainte de publicare

1. Încarcă modelele și verifică licențele.
2. Pornește aplicația în mediu cu browser.
3. Capturează la 1440×900, după 3,2 secunde și după stabilizarea GLB.
4. Compară poziția, brațul, draperia, umbrele și dimensiunile cu referința.
5. Testează mouse, scroll, mobil, reduced motion și pierderea contextului WebGL.
6. Măsoară FPS / Lighthouse pe dispozitive reale.

În această sesiune nu există un instrument control-browser disponibil. Nu au fost realizate captura browser 1440×900, verificarea animației în browser sau testarea vizuală pe telefon. TypeScript / lint / build sunt verificări separate și nu demonstrează fidelitatea vizuală.
