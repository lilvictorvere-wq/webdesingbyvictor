'use client';
import { Suspense, useEffect, useMemo, useRef } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import {Cloud,Clouds} from '@react-three/drei/core/Cloud';
import {Float} from '@react-three/drei/core/Float';
import {Line} from '@react-three/drei/core/Line';
import {Sparkles} from '@react-three/drei/core/Sparkles';
import {useGLTF} from '@react-three/drei/core/Gltf';
import {useTexture} from '@react-three/drei/core/Texture';
import * as THREE from 'three';
import { cinematicState } from '@/lib/cinematic-state';

const marble = { color: '#bcbcbc', roughness: .7, metalness: .08 };

export function Column({ position = [0, 0, 0], height = 4.6 }: { position?: [number, number, number]; height?: number }) {
  return <group position={position}>
    <mesh position={[0, .13, 0]}><boxGeometry args={[1.03, .26, 1.03]} /><meshStandardMaterial {...marble} /></mesh>
    <mesh position={[0, .34, 0]}><cylinderGeometry args={[.52, .55, .16, 24]} /><meshStandardMaterial {...marble} /></mesh>
    <mesh position={[0, height / 2 + .35, 0]}><cylinderGeometry args={[.33, .41, height, 32]} /><meshStandardMaterial {...marble} /></mesh>
    {Array.from({ length: 16 }, (_, i) => {
      const a = i * Math.PI / 8;
      return <mesh key={i} position={[Math.cos(a) * .37, height / 2 + .35, Math.sin(a) * .37]}>
        <cylinderGeometry args={[.035, .045, height - .15, 6]} /><meshStandardMaterial color="#858585" roughness={.8} />
      </mesh>;
    })}
    <mesh position={[0, height + .44, 0]}><cylinderGeometry args={[.52, .38, .22, 24]} /><meshStandardMaterial {...marble} /></mesh>
    <mesh position={[0, height + .63, 0]}><boxGeometry args={[1.05, .2, 1.05]} /><meshStandardMaterial {...marble} /></mesh>
  </group>;
}

function Temple({ compact = false }: { compact?: boolean }) {
  const pediment = useMemo(() => {
    const shape = new THREE.Shape(); shape.moveTo(-4.1, 0); shape.lineTo(0, 1.65); shape.lineTo(4.1, 0); shape.closePath();
    return new THREE.ExtrudeGeometry(shape, { depth: .42, bevelEnabled: false });
  }, []);
  useEffect(() => () => pediment.dispose(), [pediment]);
  return <group position={compact ? [0, -2.2, -1] : [2.8, -2.6, -6.5]} rotation={[0, -.2, 0]} scale={compact ? .7 : .9}>
    {[0, 1, 2].map(i => <mesh key={i} position={[0, -.16 - i * .2, 0]}><boxGeometry args={[8.5 + i * .5, .22, 3.4 + i * .5]} /><meshStandardMaterial color="#555555" roughness={.9} /></mesh>)}
    {[-3.4, -2.05, -.68, .68, 2.05, 3.4].map(x => <Column key={x} position={[x, 0, 0]} height={3.6} />)}
    <mesh position={[0, 4.46, 0]}><boxGeometry args={[8.35, .32, 1.6]} /><meshStandardMaterial {...marble} /></mesh>
    <mesh geometry={pediment} position={[0, 4.64, -.3]}><meshStandardMaterial {...marble} side={THREE.DoubleSide} /></mesh>
  </group>;
}

function Statue({ onReady }: { onReady: () => void }) {
  const { scene } = useGLTF('/models/apollo.glb', false);
  const statue = useMemo(() => {
    const model = scene.clone(true);
    const material = new THREE.MeshPhysicalMaterial({ color: '#e8e8e8', roughness: .62, metalness: .035, clearcoat: .12, clearcoatRoughness: .55 });
    model.traverse(object => { if (object instanceof THREE.Mesh) { object.material = material; object.castShadow = false; object.receiveShadow = false; } });
    return { model, material };
  }, [scene]);
  useEffect(() => { onReady(); return () => statue.material.dispose(); }, [onReady, statue]);
  return <primitive object={statue.model} position={[-.5, -2.25, .6]} rotation={[0, -.12, 0]} scale={1.12} dispose={null} />;
}

function DigitalPanel() {
  const texture = useTexture('/textures/digital-panel.webp');
  return <Float speed={.65} rotationIntensity={.12} floatIntensity={.18}>
    <group position={[2.1, -.1, 1.3]} rotation={[.08, -.28, -.08]}>
      <mesh><boxGeometry args={[2.6, 1.78, .09]} /><meshStandardMaterial color="#252525" metalness={.7} roughness={.25} /></mesh>
      <mesh position={[0, .03, .051]}><planeGeometry args={[2.46, 1.54]} /><meshBasicMaterial map={texture} toneMapped={false} /></mesh>
      <mesh position={[0, -.8, .057]}><sphereGeometry args={[.025, 8, 8]} /><meshBasicMaterial color="#cccccc" /></mesh>
    </group>
  </Float>;
}

function World({ onReady, compact = false }: { onReady: () => void; compact?: boolean }) {
  const root = useRef<THREE.Group>(null);
  const clouds = useRef<THREE.Group>(null);
  const { gl, setFrameloop, invalidate } = useThree();
  const intro = useRef(0);
  useEffect(() => { if (compact) onReady(); }, [compact, onReady]);
  useEffect(() => {
    const element = gl.domElement;
    let inViewport=true;
    const update=()=>{const running=inViewport&&!document.hidden;setFrameloop(running?'always':'demand');if(running)invalidate();};
    const observer = new IntersectionObserver(([entry]) => {inViewport=entry.isIntersecting;update();}, { threshold: .01 });
    observer.observe(element.closest('.cta,.contact-story')||element);
    const visibility = update;
    document.addEventListener('visibilitychange', visibility);
    return () => { observer.disconnect(); document.removeEventListener('visibilitychange', visibility); };
  }, [gl, setFrameloop, invalidate]);
  useFrame(({ clock, camera }, rawDelta) => {const pointer=cinematicState.pointer;
    const delta = Math.min(rawDelta, .04); intro.current = Math.min(3, intro.current + delta);
    const progress = cinematicState.progress;
    const arrival = THREE.MathUtils.smoothstep(intro.current, .4, 2.7);
    const damp = 1 - Math.exp(-delta * 2.3);
    camera.position.x = THREE.MathUtils.lerp(camera.position.x, (compact ? .5 : .8) + pointer.x * .25 + progress * 1.5, damp);
    camera.position.y = THREE.MathUtils.lerp(camera.position.y, .4 + pointer.y * .13 + progress * .35, damp);
    camera.position.z = THREE.MathUtils.lerp(camera.position.z, (compact ? 10 : 8.8) + (1 - arrival) * 2 + progress * .8, damp);
    camera.lookAt(compact ? 0 : .5, .15, -.4);
    if (root.current) root.current.rotation.y = THREE.MathUtils.lerp(root.current.rotation.y, pointer.x * .055 - progress * .1, damp);
    if (clouds.current) clouds.current.position.x = Math.sin(clock.elapsedTime * .06) * .3 - pointer.x * .12;
  });
  const orbit = useMemo(() => Array.from({ length: 100 }, (_, i) => { const a = i / 99 * Math.PI * 2; return new THREE.Vector3(Math.cos(a) * 3.7, Math.sin(a) * 3.7, -1.7); }), []);
  return <>
    <fog attach="fog" args={['#090909', 9, 23]} />
    <ambientLight intensity={.35} />
    <directionalLight position={[-4, 6, 4]} intensity={3.5} color="#ffffff" />
    <directionalLight position={[4, 2, -2]} intensity={2.1} color="#dddddd" />
    <pointLight position={[0, -1, 4]} intensity={3} color="#bcbcbc" />
    <group ref={root}>
      <Temple compact={compact} />
      {!compact && <><Column position={[4.8, -2.7, -1.6]} height={6} /><Column position={[-3.8, -2.5, -3.2]} height={3.3} />
        <Suspense fallback={null}><Statue onReady={onReady} /><DigitalPanel /></Suspense>
        <Line points={orbit} color="#bcbcbc" opacity={.2} transparent lineWidth={.65} rotation={[.1, .2, -.4]} />
        <mesh position={[.3, 1, -3.9]}><sphereGeometry args={[2.4, 32, 32]} /><meshStandardMaterial color="#252525" roughness={.95} /></mesh>
      </>}
      <Sparkles count={compact ? 18 : 48} scale={[10, 7, 5]} size={1.3} speed={.12} opacity={.45} color="#ffffff" />
      <group ref={clouds}>
        <Clouds texture="/textures/cloud.webp" limit={compact ? 12 : 32} material={THREE.MeshLambertMaterial}>
          <Cloud seed={17} position={[0, -2.6, 1]} bounds={[5, .5, 2]} segments={compact ? 6 : 16} volume={2.4} opacity={.25} speed={.06} color="#a3a3a3" fade={10} />
          {!compact && <Cloud seed={24} position={[3.5, 2, -5]} bounds={[3, .7, 1]} segments={12} volume={2} opacity={.2} speed={.04} color="#999999" fade={15} />}
        </Clouds>
      </group>
    </group>
  </>;
}

export default function AncientScene({ onReady, compact = false }: { onReady: () => void; compact?: boolean }) {
  return <Canvas dpr={[1, 1.35]} camera={{ position: [.8, .4, compact ? 10 : 10.8], fov: 39 }} gl={{ antialias: true, alpha: true, powerPreference: 'low-power' }} onCreated={({ gl }) => { gl.setClearColor('#050505', 0); }}>
    <Suspense fallback={null}><World onReady={onReady} compact={compact} /></Suspense>
  </Canvas>;
}
