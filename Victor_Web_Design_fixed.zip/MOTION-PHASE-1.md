# Victor Web Design — etapa 1, mișcare inspirată de TCM

Ramură locală: motion/tcm-phase-1. Bază: 8805a98a97bd1bbe906579371c3175dd2838c05a. Nu este publicată și nu a fost împinsă în remote.

Implementare: banda continuă se deplasează aproximativ 60px/s, cu pauză manuală, hover/focus, suspendare în afara ecranului și când fila este ascunsă. Copiile decorative sunt excluse din accesibilitate; reduced motion afișează o singură copie statică. Lățimea se măsoară după încărcarea fonturilor și la resize.

Reveal: 0,62s, decalaj de 0,07–0,08s între carduri. Eliminată suprapunerea GSAP/Motion pe cardurile portofoliului. Butoane: fundal la hover/focus, săgeată discretă și deplasare magnetică limitată. Nu s-au modificat HERO, fonturi, texte, paletă, prețuri, formulare sau linkuri.

Fișiere: app/page.tsx, app/globals.css, components/effects.tsx, components/sections.tsx, components/portfolio.tsx; componentă nouă components/service-marquee.tsx și tests/e2e/motion.spec.ts.

Verificări: TypeScript, lint și 10 teste API/sursă trecute. Testele Playwright sunt doar pregătite și listate (14 în total); nu s-au executat în browser. Build Next.js: rezultatul final este raportat în livrare. Nu s-au măsurat Lighthouse sau FPS.

Revenire: copia backup/ din arhivă păstrează starea inițială, inclusiv modificările chatbotului nepublicate. Acele modificări sunt neterminate și nu sunt incluse în ready-project/. Directorul principal original a rămas nemodificat. Nu folosiți reset --hard pe el pentru a păstra munca necomisă.

Preview HTML: versiune statică pentru revizuire locală, cu imagine cinematică și parallax, nu motorul Three.js original. Nu trimite email fără configurarea backend-ului. Proiectul Next.js complet este în ready-project/. Pentru pornire: instalați dependențele pe calculatorul local, apoi npm run dev:next. Nu se publică fără aprobare.
