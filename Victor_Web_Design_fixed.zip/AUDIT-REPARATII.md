# Audit și reparații — 9 octombrie 2026

Designul, imaginea statuii, fundalul, fonturile, prețurile și conținutul sunt păstrate.

## Probleme și reparații

- HERO: două tweens GSAP scriau opacitatea aceluiași element. Tween-ul de scroll putea captura opacitatea parțială de la intrare. Acum există un singur writer, cu valori independente pentru intrare și scroll. Revenirea la progres zero produce fade=1; cleanup șterge stilurile și semnalul camerei. `gsap.matchMedia` gestionează schimbarea preferinței de mișcare și elimină triggers/timelines.
- Randare: suspendarea folosea `frameloop=never`. Acum observarea secțiunii stabile reia explicit randarea și invalidează un cadru; suspendarea folosește demand. Imaginea cinematică rămâne dedesubt și nu depinde de WebGL. Context loss activează fallback-ul.
- Resize: activarea WebGL urmărește pragul 700 px și preferința de mișcare. Nu mai resetează `ready` pentru o scenă care rămâne montată. Mouse parallax citește evenimentul global, astfel încât canvas-ul decorativ poate avea pointer-events:none.
- Navigare: destinațiile existau în sursă. Nu există dovadă browser pentru cauza exactă a clicurilor raportate. Linkurile folosesc acum ancore native, cu navigare document complet, eliminând dependența de routerul experimental Vinext. Canvas-ul și straturile decorative nu interceptează interacțiuni. URL-urile, istoricul și funcționarea înainte de hidratare sunt păstrate.
- Portofoliu: întreaga suprafață a fiecărui card este un singur link accesibil, fără ancore imbricate. Nu există proiecte externe fictive.
- Pachete: `/contact?pachet=Starter|Business|Premium#formular`; preselectare existentă și scroll offset pentru navbar.
- Formular: blocare sincronă a trimiterilor duplicate, timeout 15s și abort la demontare, păstrarea datelor la eroare, reset numai după HTTP succes. Idempotency key către Resend păstrată pentru aceeași cerere și regenerată dacă datele se schimbă. Serverul validează originea, schema, honeypot, timpul și rata; colecția rate-limit are limită de memorie. Rate limit local fiecărui isolate, nu distribuit.
- Meniu mobil: închidere la trecerea pe desktop; focus și Escape existente păstrate. Cookie notice continuă să se închidă dacă storage este blocat.

## Fișiere

Animații și canvas: `components/effects.tsx`, `components/cinematic-hero.tsx`, `components/hero-stage.tsx`, `lib/cinematic-state.ts`, `app/globals.css`.
Navigare: `components/site-link.tsx`, `components/shell.tsx`, `components/portfolio.tsx`, `components/sections.tsx`, `components/page-intro.tsx`, `app/page.tsx`, `app/[slug]/page.tsx`, `app/portofoliu/[slug]/page.tsx`, `app/not-found.tsx`.
Formular: `components/contact.tsx`, `app/api/contact/route.ts`.
Verificări/documentație: `tests/contact-api.test.mjs`, `tests/source-audit.test.mjs`, `tests/e2e/site.spec.ts`, `playwright.config.ts`, `package.json`, `pnpm-lock.yaml`, `.gitignore`, `README.md`, acest raport.

## Verificări

Executate: 4 teste API (validare, anti-spam, configurare absentă, provider mock, idempotency, erori și rate limit), 3 teste sursă (destinații locale, resurse, proiecte), TypeScript, ESLint, build Next.js și build de hosting Vinext. Statusurile finale sunt în livrare.

9 scenarii Playwright au fost descoperite prin `playwright test --list`, fără execuție browser. Acoperă 375/390/768/1024/1440/1920 px, cinci cicluri scroll, istoric, meniul mobil, linkurile, proiectele, pachetele, validarea și răspunsurile formularului, resize și reduced motion. Răspunsurile email sunt simulate exclusiv în teste.

Nu s-au executat browser QA, capturi, măsurători FPS/Lighthouse, verificare vizuală sau confirmarea clicurilor în producție. Mediul gestionat nu oferă skill-ul control-browser; instrucțiunea Sites este: “If `$control-browser` is unavailable, skip browser QA: do not start a preview server, install a browser, or improvise another browser-control path.” Nu se declară E2E trecut.

## Configurare necesară

În producție, revizia variabilelor era 0: niciun serviciu email configurat. Sunt necesare `RESEND_API_KEY`, `CONTACT_FROM` (adresă pe domeniu verificat în Resend), `CONTACT_TO`, apoi redeploy. Pentru datele publice opționale: `NEXT_PUBLIC_CONTACT_EMAIL`, `NEXT_PUBLIC_WHATSAPP`, `NEXT_PUBLIC_INSTAGRAM`, `NEXT_PUBLIC_FACEBOOK`, `NEXT_PUBLIC_LINKEDIN`. Variabilele publice se stabilesc la build. `NEXT_PUBLIC_SITE_URL` trebuie să fie URL-ul canonical final, fără slash terminal.

Nu se promite trimitere email până la configurarea și verificarea unei livrări reale. Scena păstrează compoziția actuală: statuia/ruinele sunt imagine cinematică, iar camera, norii și panourile sunt 3D. Modelele GLB fotorealiste licențiate pentru statuia cu braț întins și ruine rămân opționale și neadăugate în acest audit.

## Rulare locală a testelor browser

Pe un mediu local cu browser disponibil: instalați dependențele și Chromium pentru Playwright, porniți `npm run dev:next`, apoi `E2E_BASE_URL=http://localhost:3000 npm run test:e2e`. Nu folosiți adresa privată publicată fără sesiunea de autentificare corespunzătoare. Testele nu pornesc automat un server.
