import {test} from 'node:test';
import assert from 'node:assert/strict';
import {runtime,nodes,Events} from './helpers/motion-runtime.mjs';
test('Meniul mobil se închide când viewport-ul trece la desktop la 768px',()=>{
 let width=390;const queries=[];const r=runtime({imports:{'next/navigation':{usePathname:()=>'/'} }});
 r.sandbox.matchMedia=query=>{const media=new Events();Object.defineProperty(media,'matches',{get:()=>width>=Number(query.match(/\d+/)[0])});queries.push(media);return media;};
 const {Header}=r.load('components/shell.tsx');const render=()=>r.render(Header);const button=()=>nodes(render(),node=>node.type==='button')[0];
 button().props.onClick();assert.equal(button().props['aria-expanded'],true);
 const cleanup=r.effects[2]();width=768;queries[0].emit('change');assert.equal(button().props['aria-expanded'],false);cleanup();assert.equal(queries[0].count(),0);
});
