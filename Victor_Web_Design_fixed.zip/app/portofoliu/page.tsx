import PageIntro from '@/components/page-intro';
import {meta} from '@/lib/seo';
import Portfolio from '@/components/portfolio';
export const metadata=meta('Portofoliu','Șase concepte demonstrative. Șase direcții creative. Niciun client sau rezultat inventat.','/portofoliu');
export default function Page(){return <><PageIntro title="Portofoliu" description="Șase concepte demonstrative. Șase direcții creative. Niciun client sau rezultat inventat." path="/portofoliu"/><section className="section"><Portfolio full/></section></>}