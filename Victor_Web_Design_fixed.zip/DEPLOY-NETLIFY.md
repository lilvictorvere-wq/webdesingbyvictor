# Victor Web Design — export pentru Netlify

Versiune sursă: 2f66651. Codul aplicației este nemodificat în acest export.

Arhiva conține proiectul Next.js complet, nu un export HTML static.
Extrage arhiva și încarcă fișierele din directorul care conține package.json într-un repository GitHub. Conectează ulterior acel repository la Netlify, numai când dorești publicarea.

## Setări Netlify
- Base directory: rădăcina proiectului (directorul package.json).
- Build command: pnpm run build:next
- Publish directory: .next
- NODE_VERSION: 22 (minimum 22.13)
- Package manager: pnpm@11.25.0, declarat în package.json.
- Next.js: 16.3.4, cu adaptorul Next.js/OpenNext detectat de Netlify.

Nu utiliza comanda implicită pnpm run build: aceasta aparține infrastructurii Sites/Vinext. Nu încărca acest ZIP prin Netlify Drop: aplicația include /contact și /api/contact dinamice.

## Variabile
Configurează NEXT_PUBLIC_SITE_URL la adresa finală HTTPS, fără slash final.
Formularul necesită RESEND_API_KEY, CONTACT_FROM (expeditor autorizat) și CONTACT_TO. Fără ele, trimiterea rămâne indisponibilă.
CONTACT_EMAIL și CONTACT_WHATSAPP sunt opționale pentru datele publice.
UPSTASH_REDIS_REST_URL și UPSTASH_REDIS_REST_TOKEN sunt opționale, recomandate pentru limitare distribuită în serverless; configurează ambele sau niciuna.
.env.example conține exclusiv exemple. Nu încărca cheile reale în GitHub și nu utiliza prefixul NEXT_PUBLIC_ pentru secrete.

## Pornire locală după instalarea Node și pnpm
pnpm install --frozen-lockfile
pnpm run dev:next

## Verificări
pnpm run typecheck
pnpm run lint
pnpm test
pnpm run build:next

TypeScript, ESLint, build Next.js și 23 de teste au trecut pe sursa exportată în mediul de lucru. Instalarea curată pe Netlify, adaptorul Netlify, browserul și trimiterea reală a emailurilor NU au fost validate. Nu sunt incluse node_modules, .next, istoricul Git sau fișiere .env cu secrete. Păstrează pnpm-lock.yaml, pnpm-workspace.yaml și toate resursele public/.

Documentele de audit incluse descriu etape anterioare; acest fișier identifică versiunea exportată. Nu s-a efectuat nicio publicare.
