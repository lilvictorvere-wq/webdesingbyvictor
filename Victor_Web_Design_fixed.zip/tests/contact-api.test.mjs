import {test} from 'node:test';
import assert from 'node:assert/strict';
import {POST} from '../app/api/contact/route.ts';
const payload=()=>({name:'Test QA',email:'qa@example.com',phone:'',type:'Website de prezentare',budget:'Business',message:'Acesta este un mesaj pentru testare.',consent:'on',website:'',started:Date.now()-5000,requestId:crypto.randomUUID()});
let index=0;
function request(data,origin='https://example.ro'){return new Request('https://example.ro/api/contact',{method:'POST',headers:{origin,'content-type':'application/json','cf-connecting-ip':`192.0.2.${++index}`},body:JSON.stringify(data)});}
test('origine, validare, honeypot, consimțământ și timp anti-spam',async()=>{
 for(const [data,origin,status] of [[payload(),'https://other.ro',403],[{...payload(),email:'invalid'},undefined,400],[{...payload(),website:'spam'},undefined,400],[{...payload(),consent:''},undefined,400],[{...payload(),started:Date.now()},undefined,400]])assert.equal((await POST(request(data,origin))).status,status);
});
test('configurarea absentă nu simulează succesul',async()=>{
 delete process.env.RESEND_API_KEY;delete process.env.CONTACT_FROM;delete process.env.CONTACT_TO;
 const response=await POST(request(payload()));assert.equal(response.status,503);assert.match((await response.json()).message,/nu este configurată/);
});
test('răspunsuri provider și idempotency: mock exclusiv în test',async()=>{
 process.env.RESEND_API_KEY='test-key';process.env.CONTACT_FROM='test@example.ro';process.env.CONTACT_TO='to@example.ro';
 const original=globalThis.fetch;
 try{
  const data=payload();globalThis.fetch=async(url,init)=>{assert.equal(url,'https://api.resend.com/emails');assert.equal(init.headers['Idempotency-Key'],data.requestId);return new Response('{}',{status:200});};
  assert.equal((await POST(request(data))).status,200);
  globalThis.fetch=async()=>new Response('{}',{status:500});assert.equal((await POST(request(payload()))).status,502);
  globalThis.fetch=async()=>{throw new Error('Network unavailable');};assert.equal((await POST(request(payload()))).status,502);
 }finally{globalThis.fetch=original;delete process.env.RESEND_API_KEY;delete process.env.CONTACT_FROM;delete process.env.CONTACT_TO;}
});
test('rate limit pentru același IP',async()=>{
 const req=()=>new Request('https://example.ro/api/contact',{method:'POST',headers:{origin:'https://example.ro','cf-connecting-ip':'192.0.2.200'},body:JSON.stringify(payload())});
 for(let i=0;i<5;i++)assert.equal((await POST(req())).status,503);
 assert.equal((await POST(req())).status,429);
});
