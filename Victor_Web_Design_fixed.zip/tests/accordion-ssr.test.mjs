import {test} from 'node:test';
import assert from 'node:assert/strict';
import * as React from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {runtime,nodes} from './helpers/motion-runtime.mjs';

test('Acordeon: serverul și clientul pornesc închise, cu fallback fără JavaScript',()=>{
 const server=runtime({imports:{react:React,
  './effects':{Reveal:({children,className})=>React.createElement('div',{className},children)},
  './site-link':{__esModule:true,default:props=>React.createElement('a',props)}
 }});
 const Component=server.load('components/services-accordion.tsx').default;
 const html=renderToStaticMarkup(React.createElement(Component));
 assert.equal((html.match(/aria-expanded="false"/g)||[]).length,6);
 assert.equal((html.match(/data-expanded="false"/g)||[]).length,6);
 assert.equal((html.match(/aria-expanded="true"/g)||[]).length,0);
 const fallback=[...html.matchAll(/<noscript>(.*?)<\/noscript>/g)];
 assert.equal(fallback.length,6);
 fallback.forEach(([markup],i)=>{
  assert.ok(markup.includes('Descrierea '+i));
  assert.ok(markup.includes('href="/service-'+i+'"'));
  assert.ok(!markup.includes('inert='));
 });
 const client=runtime();const tree=client.render(client.load('components/services-accordion.tsx').default);
 const buttons=nodes(tree,node=>node.type==='button');
 assert.equal(buttons.length,6);
 assert.ok(buttons.every(button=>button.props['aria-expanded']===false));
});
