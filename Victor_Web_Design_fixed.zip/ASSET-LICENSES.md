# Resurse vizuale și licențe

## Apollo Belvedere

Scan: Statens Museum for Kunst (SMK), colecția Den Kongelige Afstøbningssamling, replica Apollo Belvedere / KAS353.

Sursă și licență: https://commons.wikimedia.org/wiki/File:Apollo_Belvedere_-_KAS353.stl

Original: https://upload.wikimedia.org/wikipedia/commons/6/61/Apollo_Belvedere_-_KAS353.stl

CC0 1.0 Universal: https://creativecommons.org/publicdomain/zero/1.0/

Adaptare: simplificare de la 2.905.356 la 140.000 triunghiuri, orientare, normalizare la 4,5 unități, normale smooth, export GLB și compresie Meshopt. Materialul monocromatic de marmură este aplicat de aplicație. Nu este un model al personajului exact din imaginea de referință. Randarea fallback folosește același scan.

## Resurse originale

Templul și coloanele procedurale, cercurile orbitale, particulele, panoul digital, sprite-ul de nori, mockup-urile demonstrative din portofoliu și compoziția Open Graph sunt create în cod pentru acest proiect. Numele proiectelor sunt demonstrative, nu clienți reali.

## Imagine de referință

Imaginea încărcată de utilizator este utilizată pentru direcția vizuală. Nu este inclusă în fișierele publice, nu este folosită ca background și nu i se atribuie automat o licență de redistribuire. Statisticile afișate în referință nu sunt implementate.


## Hero scenic generat

`public/hero/cinematic-scene.webp`: compoziție originală creată cu instrumentul imagegen, folosind imaginea utilizatorului ca referință de stil / compoziție. Asset raster pentru strat scenic și fallback; nu este un GLB și nu i se atribuie fals o licență CC0 de scan muzeal.

Prompt utilizat: imagine cinematică monocromatică 16:9, stânga 40% neagră liberă pentru HTML; sculptură greacă monumentală centru cu păr ondulat, draperie realistă și brațul drept ridicat 25° către dreapta; ruine corintice fotorealiste în dreapta, sferă întunecată, nori, rim lighting; fără text, logo, statistici sau panouri desenate.
