import {test} from 'node:test';
import assert from 'node:assert/strict';
import {runtime,nodes} from './helpers/motion-runtime.mjs';
const settle=()=>new Promise(resolve=>setImmediate(resolve));
function button({refined=false,disabled=false}={}){return {style:{},matches:selector=>selector.includes(':disabled')?disabled:refined,closest(){return this;},getBoundingClientRect:()=>({left:0,top:0,width:100,height:40})};}
function move(r,target){r.win.emit('pointermove',{target,clientX:80,clientY:30,pointerType:'mouse'});r.flush();}
test('Pointer: reduced-motion activat oprește TOATE deplasările și resetează semnalele',()=>{
 const r=runtime();r.load('components/effects.tsx').PointerEffects();const cleanup=r.effects[0]();const target=button();move(r,target);assert.ok(target.style.transform);
 r.motion.matches=true;r.motion.emit('change');assert.equal(target.style.transform,'');move(r,target);assert.equal(target.style.transform,'');assert.deepEqual(r.signal.pointer,{x:0,y:0});cleanup();assert.equal(r.win.count()+r.doc.count()+r.motion.count()+r.pointer.count(),0);
});
test('Pointer: pornire cu reduced-motion, apoi reactivare',()=>{
 const r=runtime({reduced:true});r.load('components/effects.tsx').PointerEffects();const cleanup=r.effects[0]();r.motion.matches=false;r.motion.emit('change');const target=button();move(r,target);assert.ok(target.style.transform);cleanup();
});
test('Pointer: buton dezactivat nu primește magnetic și glow nu scrie top/left',()=>{
 const r=runtime();r.load('components/effects.tsx').PointerEffects();const cleanup=r.effects[0]();const target=button({refined:true,disabled:true});move(r,target);assert.ok(!target.style.translate);assert.equal(r.refs[0].current.style.left,undefined);assert.equal(r.refs[0].current.style.top,undefined);cleanup();
});
test('Pointer: cleanup anulează cadrul pending și Strict Mode nu dublează listeners',()=>{
 const r=runtime();r.load('components/effects.tsx').PointerEffects();let cleanup=r.effects[0]();r.win.emit('pointermove',{target:button(),clientX:10,clientY:10,pointerType:'mouse'});assert.equal(r.frameCount(),1);cleanup();assert.equal(r.frameCount(),0);assert.equal(r.win.count()+r.doc.count()+r.motion.count()+r.pointer.count(),0);cleanup=r.effects[0]();assert.equal(r.win.handlers.get('pointermove').size,1);cleanup();
});
test('HERO: import GSAP eșuat nu produce unhandled rejection',async()=>{
 const r=runtime({imports:{gsap:()=>{throw new Error('Chunk unavailable');}}});r.load('components/effects.tsx').ScrollEffects();const cleanup=r.effects[0]();await settle();await settle();assert.equal(r.signal.progress,0);cleanup();
});
test('HERO: sincronizare scroll reversibilă, cinci cicluri, și cleanup',async()=>{
 let scroll,revert,cleaned=false;const art={style:{}};
 const gsap={registerPlugin(){},matchMedia:()=>({add:(_,fn)=>{revert=fn();},revert:()=>{revert?.();cleaned=true;}}),timeline:()=>({to(){return this;},fromTo(){return this;}}),fromTo(){},set(){}};
 const r=runtime({imports:{gsap:{gsap},'gsap/ScrollTrigger':{ScrollTrigger:{create:config=>{scroll=config;}}}}});
 const hero={querySelector:selector=>selector==='.hero-stage'?art:{},querySelectorAll:()=>[{},{}]};r.doc.querySelector=()=>hero;r.win.scrollY=200;
 r.load('components/effects.tsx').ScrollEffects();const cleanup=r.effects[0]();await settle();
 for(let i=0;i<5;i++){scroll.onUpdate({progress:1});assert.ok(Number(art.style.opacity)<.06);scroll.onUpdate({progress:0});assert.equal(Number(art.style.opacity),1);assert.equal(r.signal.progress,0);}
 cleanup();assert.equal(cleaned,true);assert.equal(art.style.opacity,'');
});
test('Servicii: fiecare buton deschide/închide, exclusivitate, ARIA și tastatură',()=>{
 const r=runtime();const Component=r.load('components/services-accordion.tsx').default;
 const render=()=>r.render(Component);const buttons=()=>nodes(render(),node=>node.type==='button');
 for(let i=0;i<6;i++){buttons()[i].props.onClick();const current=buttons();assert.equal(current.filter(n=>n.props['aria-expanded']).length,1);assert.equal(current[i].props['aria-expanded'],true);const panel=nodes(render(),node=>node.props?.id===current[i].props['aria-controls'])[0];assert.equal(panel.props.inert,false);current[i].props.onClick();assert.equal(buttons()[i].props['aria-expanded'],false);}
 const current=buttons();let focused=-1;current.forEach((node,i)=>node.props.ref({focus:()=>{focused=i;}}));current[0].props.onKeyDown({key:'End',preventDefault(){}});assert.equal(focused,5);current[5].props.onKeyDown({key:'ArrowDown',preventDefault(){}});assert.equal(focused,0);
});

test('Scroll Reveal: o singură execuție, reduced-motion și cleanup',async()=>{
 const r=runtime();let intersect,disconnected=0,cancelled=0,played=0;const section={};
 const target={tagName:'DIV',dataset:{revealDelay:'0.06'},isConnected:true,hasAttribute:()=>true,closest:selector=>selector==='.section'?section:null,matches:()=>true,querySelectorAll:()=>[],animate:()=>{played++;return {finished:new Promise(()=>{}),cancel:()=>{cancelled++;}};}};
 const main={...r.doc,matches:()=>false,querySelectorAll:()=>[target],addEventListener:r.doc.addEventListener.bind(r.doc),removeEventListener:r.doc.removeEventListener.bind(r.doc)};
 r.doc.getElementById=()=>main;r.sandbox.Element.prototype.animate=()=>{};r.sandbox.HTMLImageElement=class{};
 r.sandbox.IntersectionObserver=class{constructor(fn){intersect=fn;}observe(){}unobserve(){}disconnect(){disconnected++;}};
 r.sandbox.MutationObserver=class{observe(){}disconnect(){disconnected++;}};r.win.IntersectionObserver=r.sandbox.IntersectionObserver;
 r.load('components/section-reveals.tsx').default();const cleanup=r.effects[0]();
 intersect([{target,isIntersecting:true}]);intersect([{target,isIntersecting:true}]);assert.equal(played,1);
 r.motion.matches=true;r.motion.emit('change');assert.equal(cancelled,1);cleanup();assert.equal(disconnected,2);assert.equal(r.doc.count()+r.motion.count(),0);
});
test('Marquee: măsurare, fază păstrată la resize, pauze și cleanup',async()=>{
 const r=runtime();let resized,intersect,width=800,disconnected=0;const style={setProperty(key,value){this[key]=value;}};
 const animation={animationName:'service-band',currentTime:2000};let started=false;
 const rail={dataset:{},style,querySelector:()=>({getBoundingClientRect:()=>({width})}),getAnimations:()=>started?[animation]:[]};
 const container={dataset:{}};
 r.sandbox.ResizeObserver=class{constructor(fn){resized=fn;}observe(){}disconnect(){disconnected++;}};
 r.sandbox.IntersectionObserver=class{constructor(fn){intersect=fn;}observe(){}disconnect(){disconnected++;}};
 r.load('components/service-marquee.tsx').default();r.refs[0].current=container;r.refs[1].current=rail;const cleanup=r.effects[0]();started=true;
 assert.equal(rail.dataset.ready,'true');assert.equal(parseFloat(style['--marquee-distance']),-800);assert.equal(parseFloat(style['--marquee-duration']),800/60);
 width=1600;resized();assert.equal(animation.currentTime,4000);assert.equal(parseFloat(style['--marquee-distance']),-1600);
 intersect([{isIntersecting:false}]);assert.equal(container.dataset.visible,'false');r.doc.hidden=true;r.doc.emit('visibilitychange');assert.equal(container.dataset.hidden,'true');
 cleanup();assert.equal(disconnected,2);assert.equal(r.doc.count(),0);assert.equal(rail.dataset.ready,undefined);await settle();assert.equal(rail.dataset.ready,undefined);
});
test('HERO: unmount înainte de import nu inițializează GSAP',async()=>{
 let called=0;const r=runtime({imports:{gsap:{gsap:{registerPlugin:()=>{called++;}}},'gsap/ScrollTrigger':{ScrollTrigger:{}}}});
 r.load('components/effects.tsx').ScrollEffects();const cleanup=r.effects[0]();cleanup();await settle();assert.equal(called,0);
});

test('Scroll Reveal: mesajele live ale formularului rămân în afara animațiilor decorative',()=>{
 const r=runtime();const observed=[];
 const make=(live)=>({tagName:'P',dataset:{},isConnected:true,hasAttribute:()=>false,
  closest:selector=>selector==='.section'?{}:selector.includes('aria-live')&&live?{}:null,
  matches:()=>true,querySelectorAll:()=>[]});
 const description=make(false),status=make(true);
 const main={matches:()=>false,querySelectorAll:()=>[description,status],addEventListener(){},removeEventListener(){}};
 r.doc.getElementById=()=>main;r.sandbox.Element.prototype.animate=()=>{};
 r.sandbox.IntersectionObserver=class{observe(el){observed.push(el);}unobserve(){}disconnect(){}};
 r.sandbox.MutationObserver=class{observe(){}disconnect(){}};
 r.win.IntersectionObserver=r.sandbox.IntersectionObserver;
 r.load('components/section-reveals.tsx').default();const cleanup=r.effects[0]();
 assert.equal(observed.includes(description),true);
 assert.equal(observed.includes(status),false,'Mesajul role=status nu trebuie ascuns de Scroll Reveal');cleanup();
});
