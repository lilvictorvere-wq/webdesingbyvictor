import {test,expect} from '@playwright/test';
for(const width of [375,390,768,1024,1440,1920]){
 test(`Acordeon servicii — ${width}px`,async({page})=>{
  const errors:string[]=[];page.on('pageerror',error=>errors.push(error.message));
  await page.setViewportSize({width,height:900});await page.goto('/');
  const section=page.locator('#servicii');await section.scrollIntoViewIfNeeded();
  const triggers=section.locator('.service-accordion-trigger');await expect(triggers).toHaveCount(6);
  for(let index=0;index<6;index++){
   const trigger=triggers.nth(index);await trigger.click();await expect(trigger).toHaveAttribute('aria-expanded','true');
   const panel=page.locator(`[id="${await trigger.getAttribute('aria-controls')}"]`);
   await expect(panel.getByRole('link',{name:'Descoperă serviciul'})).toBeVisible();
   expect(await triggers.evaluateAll(elements=>elements.filter(el=>el.getAttribute('aria-expanded')==='true').length)).toBe(1);
   await trigger.click();await expect(trigger).toHaveAttribute('aria-expanded','false');
   await expect(panel).toHaveAttribute('inert','');
  }
  await triggers.first().focus();await page.keyboard.press('Enter');await expect(triggers.first()).toHaveAttribute('aria-expanded','true');
  await page.keyboard.press('Space');await expect(triggers.first()).toHaveAttribute('aria-expanded','false');
  await page.keyboard.press('End');await expect(triggers.last()).toBeFocused();await page.keyboard.press('Home');await expect(triggers.first()).toBeFocused();
  await triggers.first().click();await section.getByRole('link',{name:'Descoperă serviciul'}).first().click();await expect(page).toHaveURL(/\/creare-site-web$/);
  expect(errors).toEqual([]);expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
 });
}
test('Servicii fără JavaScript și reduced motion',async({browser,page})=>{
 const context=await browser.newContext({javaScriptEnabled:false});const staticPage=await context.newPage();await staticPage.goto(process.env.E2E_BASE_URL||'http://localhost:3000');
 await expect(staticPage.locator('#servicii .service-accordion-content p')).toHaveCount(6);
 for(const panel of await staticPage.locator('#servicii .service-accordion-panel').all())await expect(panel).toBeVisible();await context.close();
 await page.emulateMedia({reducedMotion:'reduce'});await page.goto('/');await page.locator('#servicii').scrollIntoViewIfNeeded();
 const trigger=page.locator('#servicii .service-accordion-trigger').first();await trigger.click();
 await expect(page.locator('#servicii .service-accordion-panel').first()).toHaveCSS('transition-duration','0s');
});
