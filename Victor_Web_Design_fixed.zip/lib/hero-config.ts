/** Asset slots intentionally empty: the previous Apollo pose is not a substitute. */
export const heroConfig = {
  statueUrl: process.env.NEXT_PUBLIC_HERO_STATUE_URL || '',
  ruinsUrl: process.env.NEXT_PUBLIC_HERO_RUINS_URL || '',
  fallbackUrl: process.env.NEXT_PUBLIC_HERO_FALLBACK_URL || '/hero/cinematic-scene.webp',
  scenicPlateUrl: '/hero/cinematic-scene.webp',
  introSeconds: 3.2,
  statue: { height: 7.8, position: [-1.6, -4.1, .3] as [number, number, number], yaw: -.1 },
  ruins: { height: 10.5, position: [3.8, -4.3, -2.4] as [number, number, number], yaw: -.15 },
};
