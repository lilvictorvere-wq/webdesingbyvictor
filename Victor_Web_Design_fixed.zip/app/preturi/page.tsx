import PageIntro from '@/components/page-intro';
import {meta} from '@/lib/seo';
import {Pricing} from '@/components/sections';
export const metadata=meta('Prețuri creare website','Pachete orientative pentru site-uri de prezentare și proiecte personalizate.','/preturi');
export default function Page(){return <><PageIntro title="Prețuri creare website" description="Pachete orientative pentru site-uri de prezentare și proiecte personalizate." path="/preturi"/><Pricing/></>}