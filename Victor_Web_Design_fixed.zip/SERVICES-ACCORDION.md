# Victor Web Design — acordeon Servicii

Modificare locală, fără publicare. Punct de revenire anterior: `9807f4d` pe ramura `motion/tcm-phase-1`.

## Implementare

- Componentă client `components/services-accordion.tsx`, conectată exclusiv în `Services` din `components/sections.tsx` (homepage și pagina Servicii).
- Cele șase titluri și descrieri provin din `lib/content.ts`, nemodificat. Linkurile către paginile serviciilor sunt păstrate.
- Un singur serviciu deschis; click repetat îl închide. Butoane native, Enter/Space, săgeți sus/jos, Home/End, `aria-expanded`, `aria-controls`, regiuni etichetate. Panourile închise sunt `inert` și excluse din navigarea prin Tab.
- CSS strict sub `#servicii`: extindere grid `0fr`–`1fr` de 350 ms, opacity, hover 200 ms; înălțime naturală, text cu împachetare, fără imagini suprapuse. Preferința reduced-motion dezactivează tranzițiile.
- Descrierile sunt vizibile în HTML server fără JavaScript; după hidratare începe comportamentul de acordeon. Această îmbunătățire progresivă poate compacta secțiunea la hidratare.
- Scroll Reveal existent păstrat pe rânduri. Conținutul interior nu primește încă o animație concurentă. HERO și toate celelalte secțiuni păstrate.
- Nu există imagini specifice serviciilor în datele actuale; nu s-au adăugat resurse.

## Validare

TypeScript, ESLint, build Next.js și cele 10 teste Node sunt verificate. Testele Playwright pentru șase lățimi, tastatură, reduced-motion și fallback fără JS sunt pregătite; listarea nu înseamnă executare. Browser QA nu a fost executată: mediul Sites nu oferă control-browser. Nu sunt confirmate vizual suprapunerile, fluiditatea sau interacțiunile în browser.

## Livrare

`ready-project` conține sursa Next.js. `preview-html/index.html` este previzualizarea statică locală cu JavaScript pentru acordeon. Scena Three.js completă și backendul formularului aparțin aplicației Next.js, nu exportului static. Pagina publicată nu se schimbă.
