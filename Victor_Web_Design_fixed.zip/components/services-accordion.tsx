'use client';

import {useId,useRef,useState,type KeyboardEvent} from 'react';
import {ArrowUpRight,Plus} from 'lucide-react';
import Link from './site-link';
import {Reveal} from './effects';
import {services} from '@/lib/content';

/** Identical closed state on server and client; noscript preserves descriptions. */
export default function ServicesAccordion(){
 const [active,setActive]=useState<string|null>(null);
 const prefix=useId();
 const buttons=useRef<(HTMLButtonElement|null)[]>([]);
 function navigate(event:KeyboardEvent<HTMLButtonElement>,index:number){
  const next=event.key==='ArrowDown'?(index+1)%services.length:event.key==='ArrowUp'?(index+services.length-1)%services.length:event.key==='Home'?0:event.key==='End'?services.length-1:null;
  if(next===null)return;
  event.preventDefault();buttons.current[next]?.focus();
 }
 return <div className="services-accordion" data-ready="true">
  {services.map((service,index)=>{
   const expanded=active===service.slug;
   const triggerId=`${prefix}-service-${index}`;
   const panelId=`${prefix}-panel-${index}`;
   return <Reveal key={service.slug} className="service-accordion-item" delay={index*.06}>
    <h3 className="service-accordion-heading">
     <button type="button" id={triggerId} className="service-accordion-trigger" ref={node=>{buttons.current[index]=node;}} aria-expanded={expanded} aria-controls={panelId} onKeyDown={event=>navigate(event,index)} onClick={()=>setActive(current=>current===service.slug?null:service.slug)}>
      <span className="service-accordion-number" aria-hidden="true">{String(index+1).padStart(2,'0')}</span>
      <span className="service-accordion-title">{service.name}</span>
      <span className="service-accordion-indicator" aria-hidden="true"><Plus size={22}/></span>
     </button>
    </h3>
    <div id={panelId} role="region" aria-labelledby={triggerId} aria-hidden={!expanded} inert={!expanded} className="service-accordion-panel" data-expanded={expanded}>
     <div className="service-accordion-inner"><div className="service-accordion-content">
      <p>{service.description}</p>
      <Link href={'/'+service.slug} className="text-link">Descoperă serviciul <ArrowUpRight size={18}/></Link>
     </div></div>
    </div>
    <noscript><div className="service-accordion-content">
     <p>{service.description}</p>
     <Link href={'/'+service.slug} className="text-link">Descoperă serviciul <ArrowUpRight size={18}/></Link>
    </div></noscript>
   </Reveal>;
  })}
 </div>;
}
