import PageIntro from '@/components/page-intro';
import {meta} from '@/lib/seo';
import {Services} from '@/components/sections';
export const metadata=meta('Servicii digitale','Strategie, design și dezvoltare pentru o prezență online construită cu sens.','/servicii');
export default function Page(){return <><PageIntro title="Servicii digitale" description="Strategie, design și dezvoltare pentru o prezență online construită cu sens." path="/servicii"/><Services/></>}